import AppKit
import ApplicationServices
import Foundation
let color = CGColor(red: 0.125, green: 0.25, blue: 0.75, alpha: 0.5)
let space = color.colorSpace!
print(color.numberOfComponents, color.components!, color.alpha, color.pattern as Any)
print(space.model.rawValue, space.numberOfComponents, space.name as Any, space.copyICCData() as Any, space.baseColorSpace as Any)
let path = CGMutablePath()
path.move(to: CGPoint(x: 0, y: 1))
path.addQuadCurve(to: CGPoint(x: 2, y: 3), control: CGPoint(x: 4, y: 5))
path.applyWithBlock { p in
    let e = p.pointee
    print(e.type.rawValue, e.points[0])
}
print(path.isEmpty)
