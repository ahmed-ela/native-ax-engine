import AppKit
import ApplicationServices
import Foundation
typealias NativeTypeID = @convention(c) () -> CFTypeID
typealias NativeLength = @convention(c) (CFTypeRef) -> CFIndex
typealias NativeBytes = @convention(c) (CFTypeRef) -> UnsafePointer<UInt8>?
typealias NativeCopy = @convention(c) (CFTypeRef) -> Unmanaged<CFTypeRef>?
func load<T>(_ name: String, _ type: T.Type) -> T? {
    guard let symbol = dlsym(UnsafeMutableRawPointer(bitPattern: -2), name) else { return nil }
    return unsafeBitCast(symbol, to: type)
}
let id = load("AXTextMarkerGetTypeID", NativeTypeID.self)!
let length = load("AXTextMarkerGetLength", NativeLength.self)!
let bytes = load("AXTextMarkerGetBytePtr", NativeBytes.self)!
let copy = load("AXTextMarkerRangeCopyStartMarker", NativeCopy.self)!
let input: [UInt8] = [0,255,1,34,128]
let marker = input.withUnsafeBufferPointer { AXTextMarkerCreate(nil, $0.baseAddress!, $0.count) }
let range = AXTextMarkerRangeCreate(nil, marker, marker)
let endpoint = copy(range)!.takeRetainedValue()
print(id(), length(endpoint), Data(bytes: bytes(endpoint)!, count: length(endpoint)).base64EncodedString())
