let helperCounts = ["native_menu_reference_retry_fixtures": try nativeMenuReferenceRetrySelfTest(),
                    "native_scalar_recovery_fixtures": try nativeScalarRecoverySelfTest(),
                    "native_scalar_unsupported_retry_fixtures": try nativeScalarUnsupportedRetrySelfTest()]
let rootPID: pid_t = 47001, prefixPID: pid_t = 47002, ownerPID: pid_t = 47003
let root = AXUIElementCreateApplication(rootPID), prefix = AXUIElementCreateApplication(prefixPID)
let owner = AXUIElementCreateApplication(ownerPID), changed = AXUIElementCreateApplication(47004)
let endpoint = AXUIElementCreateApplication(47005)
let selector: [[String: Any]] = [["attribute": "AXChildren", "value_path": [0]], ["attribute": "AXChildren", "value_path": [0]]]
let roleRead = ReadResult<CFTypeRef>(value: "AXMenuItem" as CFString, error: .success, attempts: 1)
let original = ReadResult<CFTypeRef>(value: nil, error: .attributeUnsupported, attempts: 1)
var unsupported = AXError.attributeUnsupported, noValue = AXError.noValue
let unsupportedEnvelope = AXValueCreate(.axError, &unsupported)!, absenceEnvelope = AXValueCreate(.axError, &noValue)!
let goodStatus = ReadResult<CFTypeRef>(value: nil, error: .success, attempts: 1).status
func recorded(_ path: [[String: Any]]) -> (element: AXUIElement, pid: pid_t)? {
    if path.isEmpty { return (root, rootPID) }
    if canonical(path) == canonical(Array(selector.prefix(1))) { return (prefix, prefixPID) }
    if canonical(path) == canonical(selector) { return (owner, ownerPID) }
    return nil
}
func fresh(mode: String = "first_mismatch", readError: AXError = .success,
           pidError: AXError = .success, pidMismatch: Bool = false,
           process: Bool = true, timeout: AXError = .success) -> NativeScalarRefreshResult {
    refreshNativeScalarTarget(selectorPath: selector, rootPID: rootPID, expectedPID: ownerPID,
        recordedAtPath: recorded, processMatches: { _ in process }, createRoot: { mode == "root_changed" ? changed : root },
        setTimeout: { _ in timeout }, readAttribute: { current, _ in
            var value: CFTypeRef
            if mode == "missing_index" { value = [] as CFArray }
            else if mode == "wrong_type" { value = [kCFBooleanTrue!] as CFArray }
            else if CFEqual(current, root) { value = [mode == "first_mismatch" ? changed : prefix] as CFArray }
            else { value = [mode == "last_mismatch" ? changed : owner] as CFArray }
            return ReadResult(value: value, error: readError, attempts: 1)
        }, elementPID: { current in
            let expected = CFEqual(current, prefix) || mode == "first_mismatch" ? prefixPID : ownerPID
            return ReadResult(value: pidError == .success ? NSNumber(value: expected + (pidMismatch ? 1 : 0)) : nil,
                              error: pidError, attempts: 1)
        })
}
func retained(target: AXUIElement = owner, rootError: AXError = .success, ownerError: AXError = .success,
              rootNativePID: pid_t = rootPID, ownerNativePID: pid_t = ownerPID,
              process: (pid_t) -> Bool = { _ in true }) -> NativeScalarRefreshResult {
    validateRetainedNativeScalarTarget(nodeID: 2, rootID: 0, rootPID: rootPID, expectedPID: ownerPID,
        ownerRole: "AXMenuItem", ownerRoleStatus: roleRead.status, retainedOwner: target,
        recordedAtID: { id in id == 0 ? (root, rootPID) : id == 2 ? (owner, ownerPID) : nil },
        processMatches: process, elementPID: { current in
            let isRoot = CFEqual(current, root), error = isRoot ? rootError : ownerError
            return ReadResult(value: error == .success ? NSNumber(value: isRoot ? rootNativePID : ownerNativePID) : nil,
                              error: error, attempts: 1)
        })
}
var actualQueries = 0, actualRetainedValidations = 0
func composite(_ next: ReadResult<CFTypeRef>, attribute: String = "AXTopLevelUIElement",
               bulk: CFTypeRef = unsupportedEnvelope,
               refreshed: () -> NativeScalarRefreshResult = { fresh() },
               before: @escaping () -> NativeScalarRefreshResult = { retained() },
               after: @escaping () -> NativeScalarRefreshResult = { retained() },
               postIdentity: Bool = true) -> ReadResult<CFTypeRef> {
    actualQueries = 0; actualRetainedValidations = 0
    return recoverNativeMetadataReads([attribute], initial: [attribute: original],
        batchQuery: { ReadResult(value: [bulk] as CFArray, error: .success, attempts: 1) },
        arrayQuery: { _, _ in fatalError("Known scalar metadata must never use array queries") },
        scalarQuery: { name, initial in
            recoverNativeScalar(name, initial, refresh: refreshed, query: { target in
                precondition(CFEqual(target, owner), "Replacement menu references must never supply the query target")
                actualQueries += 1
                return next
            }, queryIdentityMatches: { postIdentity },
            retainedTarget: { actualRetainedValidations += 1; return before() },
            retainedQueryValidation: { target in
                precondition(CFEqual(target, owner), "Retained post-query checks must bind the same original handle")
                return after()
            })
        })[attribute]!
}
func encoded(_ value: CFTypeRef) -> Any {
    guard CFGetTypeID(value) == AXUIElementGetTypeID() else { fatalError("Only real native reference scalar values are exported by this fixture collection") }
    let ref = value as! AXUIElement
    let id = CFEqual(ref, root) ? 0 : CFEqual(ref, prefix) ? 1 : CFEqual(ref, owner) ? 2 : CFEqual(ref, endpoint) ? 3 : -1
    precondition(id >= 0, "All returned native references must have an explicit synthetic binding")
    return ["type": "AXUIElement", "id": id]
}
var cases: [[String: Any]] = []
var totalQueries = 0, totalRetainedQueries = 0, totalWithheld = 0, totalValues = 0, totalAbsences = 0
func record(_ label: String, _ result: ReadResult<CFTypeRef>, attribute: String = "AXTopLevelUIElement") {
    var attrs: [String: Any] = ["AXRole": "AXMenuItem"], statuses: [String: Any] = ["AXRole": roleRead.status, attribute: result.status]
    var recoveries: [String: Any] = [:], failures: [[String: Any]] = [], absent: [[String: Any]] = []
    if result.error == .success, let value = result.value { attrs[attribute] = encoded(value) }
    var valueCount = 0, absenceCount = 0, retainedCount = 0, withheld = 0, retainedValues = 0, retainedAbsences = 0
    if let trace = result.recovery {
        recoveries[attribute] = trace
        if trace["resolved"] as? Bool == true {
            if trace["resolution_kind"] as? String == "absence" { absenceCount = 1 } else { valueCount = 1 }
        }
        for query in trace["queries"] as? [[String: Any]] ?? [] where query["method"] as? String == "native_scalar_recovery" {
            if query["query_target"] as? String == "retained_original_reference", query["query_status"] is [String: Any] {
                retainedCount = 1
                if query["resolved"] as? Bool == true {
                    if query["resolution_kind"] as? String == "absence" { retainedAbsences = 1 }
                    else if query["resolution_kind"] as? String == "value" { retainedValues = 1 }
                }
            } else if query["retained_reference"] is [String: Any], query["query_status"] is NSNull { withheld = 1 }
        }
    }
    if result.error == .noValue { absent.append(["node": 2, "attribute": attribute, "status": result.status]) }
    else if result.error != .success { failures.append(["node": 2, "attribute": attribute, "stage": "attribute_read", "status": result.status]) }
    func identity(_ pid: pid_t, _ time: String) -> [String: Any] { ["pid": Int(pid), "launch_date": time, "fixture": "synthetic_captured_process_identity"] }
    let rootIdentity = identity(rootPID, "2026-10-10T00:00:00Z"), prefixIdentity = identity(prefixPID, "2026-10-10T00:00:01Z")
    let ownerIdentity = identity(ownerPID, "2026-10-10T00:00:02Z"), endpointIdentity = identity(47005, "2026-10-10T00:00:03Z")
    let rootNode: [String: Any] = ["id": 0, "pid": Int(rootPID), "process_identity": rootIdentity, "selector_path": [],
        "attribute_names": ["AXChildren"], "attributes": ["AXChildren": [["type": "AXUIElement", "id": 1]]],
        "attribute_statuses": ["AXChildren": goodStatus], "native_read_recoveries": [:], "action_names": [], "action_names_status": goodStatus]
    let prefixNode: [String: Any] = ["id": 1, "pid": Int(prefixPID), "process_identity": prefixIdentity, "selector_path": Array(selector.prefix(1)),
        "attribute_names": ["AXChildren"], "attributes": ["AXChildren": [["type": "AXUIElement", "id": 2]]],
        "attribute_statuses": ["AXChildren": goodStatus], "native_read_recoveries": [:], "action_names": [], "action_names_status": goodStatus]
    let ownerNode: [String: Any] = ["id": 2, "pid": Int(ownerPID), "process_identity": ownerIdentity, "selector_path": selector,
        "attribute_names": ["AXRole", attribute], "attributes": attrs, "attribute_statuses": statuses,
        "native_read_recoveries": recoveries, "action_names": [], "action_names_status": goodStatus]
    let endpointNode: [String: Any] = ["id": 3, "pid": 47005, "process_identity": endpointIdentity, "selector_path": [],
        "fixture": "synthetic_native_reference_endpoint_binding", "attribute_names": [], "attributes": [:], "attribute_statuses": [:],
        "native_read_recoveries": [:], "action_names": [], "action_names_status": goodStatus]
    let snapshot: [String: Any] = ["app": rootIdentity, "root_id": 0, "nodes": [rootNode, prefixNode, ownerNode, endpointNode], "node_count": 4,
        "metadata_classification_version": 2, "native_read_recovery_outcome_version": 2, "scalar_recovery_version": 3,
        "metadata_failures": failures, "metadata_read_failures": failures, "serialization_warnings": [], "absent_attribute_values": absent,
        "native_metadata_failure_summary": nativeMetadataFailureSummary(failures), "native_read_recovery_attempts": recoveries.count,
        "native_read_recovery_successes": valueCount + absenceCount, "native_read_recovery_value_successes": valueCount,
        "native_read_recovery_absence_successes": absenceCount, "native_scalar_retained_reference_attempts": retainedCount,
        "native_scalar_retained_reference_withheld": withheld, "native_scalar_retained_reference_value_successes": retainedValues,
        "native_scalar_retained_reference_absence_successes": retainedAbsences,
        "scope": ["hierarchy_attributes": ["AXChildren", "AXWindows", "AXRows", "AXColumns"]]]
    cases.append(["label": label, "snapshot": snapshot, "actual_scalar_calls": actualQueries, "actual_retained_before_validations": actualRetainedValidations])
    totalQueries += actualQueries; totalRetainedQueries += retainedCount; totalWithheld += withheld
    totalValues += valueCount; totalAbsences += absenceCount
}
let typed = ReadResult<CFTypeRef>(value: endpoint, error: .success, attempts: 1)
record("isolated_intermediate_menu_wrapper_mismatch_original_reference_typed", composite(typed))
record("retained_explicit_native_noValue_drops_untrusted_ref", composite(ReadResult(value: changed, error: .noValue, attempts: 1)))
record("retained_still_unsupported", composite(ReadResult(value: owner, error: .attributeUnsupported, attempts: 1)))
record("retained_native_owner_no_longer_live", composite(ReadResult(value: nil, error: .invalidUIElement, attempts: 1)))
record("retained_nil_success_is_unresolved", composite(ReadResult(value: nil, error: .success, attempts: 1)))
record("retained_wrong_native_scalar_type", composite(ReadResult(value: [] as CFArray, error: .success, attempts: 1)))
let afterCases: [(String, () -> NativeScalarRefreshResult)] = [
    ("post_query_owner_native_PID_failure", { retained(ownerError: .invalidUIElement) }),
    ("post_query_root_native_PID_failure", { retained(rootError: .invalidUIElement) }),
    ("post_query_owner_native_PID_changed", { retained(ownerNativePID: ownerPID + 1) }),
    ("post_query_owner_launch_changed", { retained(process: { $0 != ownerPID }) }),
    ("post_query_root_launch_changed", { retained(process: { $0 != rootPID }) })]
for (label, after) in afterCases { record(label, composite(typed, after: after)) }
record("existing_post_query_identity_guard_remains_required", composite(typed, postIdentity: false))
let beforeCases: [(String, () -> NativeScalarRefreshResult)] = [
    ("retained_registry_binding_swapped_before_query", { retained(target: changed) }),
    ("retained_root_native_PID_failure_before_query", { retained(rootError: .invalidUIElement) }),
    ("retained_owner_native_PID_failure_before_query", { retained(ownerError: .invalidUIElement) }),
    ("retained_root_native_PID_changed_before_query", { retained(rootNativePID: rootPID + 1) }),
    ("retained_owner_native_PID_changed_before_query", { retained(ownerNativePID: ownerPID + 1) }),
    ("retained_root_launch_changed_before_query", { retained(process: { $0 != rootPID }) }),
    ("retained_owner_launch_changed_before_query", { retained(process: { $0 != ownerPID }) })]
for (label, before) in beforeCases { record(label, composite(typed, before: before)) }
let refreshCases: [(String, () -> NativeScalarRefreshResult)] = [
    ("fresh_root_not_CFEqual_no_retained_route", { fresh(mode: "root_changed") }),
    ("fresh_native_prefix_read_failed_no_retained_route", { fresh(readError: .failure) }),
    ("fresh_native_value_path_missing_no_retained_route", { fresh(mode: "missing_index") }),
    ("fresh_native_selected_type_wrong_no_retained_route", { fresh(mode: "wrong_type") }),
    ("fresh_native_prefix_PID_failed_no_retained_route", { fresh(pidError: .invalidUIElement) }),
    ("fresh_native_prefix_PID_changed_no_retained_route", { fresh(pidMismatch: true) }),
    ("fresh_native_launch_identity_changed_no_retained_route", { fresh(process: false) }),
    ("fresh_native_timeout_failed_no_retained_route", { fresh(timeout: .failure) })]
for (label, refreshed) in refreshCases { record(label, composite(typed, refreshed: refreshed)) }
record("normal_fresh_exact_reference_typed_query", composite(typed, refreshed: { fresh(mode: "exact") }))
record("normal_fresh_exact_reference_explicit_absence", composite(ReadResult(value: nil, error: .noValue, attempts: 1), refreshed: { fresh(mode: "exact") }))
record("last_menu_prefix_mismatch_after_verified_ancestor_typed", composite(typed, refreshed: { fresh(mode: "last_mismatch") }))
record("last_menu_prefix_mismatch_original_reference_still_unsupported", composite(ReadResult(value: nil, error: .attributeUnsupported, attempts: 1), refreshed: { fresh(mode: "last_mismatch") }))
var processChecks = 0
record("launch_changes_during_retained_native_PID_validation", composite(typed, before: { retained(process: { _ in processChecks += 1; return processChecks < 3 }) }))
record("correct_bulk_native_value_needs_no_scalar_query", composite(typed, bulk: endpoint))
record("confirmed_bulk_native_absence_needs_no_scalar_query", composite(typed, bulk: absenceEnvelope))
record("other_scalar_attribute_mismatch_never_uses_retained_route", composite(typed, attribute: "AXGrowArea"), attribute: "AXGrowArea")
let artifact: [String: Any] = ["fixture_kind": "offline_independent_native_menu_reference_retry_cases",
    "fixture_scope": "Independent synthetic caller contexts execute actual Swift helpers using constructor-only native objects and mocked native reads/PID/launch callbacks. Saved root/prefix/owner selectors and original registry bindings are consistent per case. Changed wrappers are never used as scalar query targets. These are offline helper cases, not a captured native app graph; no native application messaging, UI actions, app restarts or permission changes occurred.",
    "helper_fixture_counts": helperCounts, "cases": cases, "case_count": cases.count,
    "total_scalar_calls": totalQueries, "total_retained_scalar_calls": totalRetainedQueries, "total_retained_queries_withheld": totalWithheld,
    "total_value_resolutions": totalValues, "total_absence_resolutions": totalAbsences]
let output = URL(fileURLWithPath: "/Users/ahmedelamin/Documents/Codex/2026-10-09/i-ha/native-ax-engine/artifacts/native-menu-reference-retry-20261010/native-query-fixtures.json")
try JSONSerialization.data(withJSONObject: artifact, options: [.prettyPrinted, .sortedKeys]).write(to: output, options: .atomic)
print(String(data: try JSONSerialization.data(withJSONObject: ["artifact": output.path, "cases": cases.count, "native_menu_reference_retry_fixtures": helperCounts["native_menu_reference_retry_fixtures"]!, "scalar_calls": totalQueries, "retained_calls": totalRetainedQueries, "withheld": totalWithheld, "values": totalValues, "absences": totalAbsences], options: [.sortedKeys]), encoding: .utf8)!)
