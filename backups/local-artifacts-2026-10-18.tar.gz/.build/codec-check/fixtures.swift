import AppKit
import ApplicationServices
import Foundation
enum EngineError: Error { case message(String) }
enum NativeTextCodec {
    typealias TypeIDFunction = @convention(c) () -> CFTypeID
    typealias LengthFunction = @convention(c) (CFTypeRef) -> CFIndex
    typealias BytesFunction = @convention(c) (CFTypeRef) -> UnsafePointer<UInt8>?
    typealias CopyFunction = @convention(c) (CFTypeRef) -> Unmanaged<CFTypeRef>?
    typealias CreateMarkerFunction = @convention(c) (CFAllocator?, UnsafePointer<UInt8>, CFIndex) -> Unmanaged<CFTypeRef>?
    typealias CreateRangeFunction = @convention(c) (CFAllocator?, CFTypeRef, CFTypeRef) -> Unmanaged<CFTypeRef>?

    struct APIs {
        var markerTypeID: TypeIDFunction?
        var markerLength: LengthFunction?
        var markerBytes: BytesFunction?
        var rangeTypeID: TypeIDFunction?
        var copyStart: CopyFunction?
        var copyEnd: CopyFunction?
    }

    static func symbol<T>(_ name: String, as type: T.Type) -> T? {
        // Darwin's RTLD_DEFAULT macro is ((void *) -2); Swift cannot import
        // that pointer-valued macro. Resolve only documented public symbols.
        guard let address = dlsym(UnsafeMutableRawPointer(bitPattern: -2), name) else { return nil }
        return unsafeBitCast(address, to: type)
    }

    static let native = APIs(
        markerTypeID: symbol("AXTextMarkerGetTypeID", as: TypeIDFunction.self),
        markerLength: symbol("AXTextMarkerGetLength", as: LengthFunction.self),
        markerBytes: symbol("AXTextMarkerGetBytePtr", as: BytesFunction.self),
        rangeTypeID: symbol("AXTextMarkerRangeGetTypeID", as: TypeIDFunction.self),
        copyStart: symbol("AXTextMarkerRangeCopyStartMarker", as: CopyFunction.self),
        copyEnd: symbol("AXTextMarkerRangeCopyEndMarker", as: CopyFunction.self)
    )

    static func marker(_ value: CFTypeRef, type: CFTypeID, apis: APIs, warning: (String) -> Void) -> [String: Any] {
        var result: [String: Any] = ["type": "AXTextMarker", "cf_type_id": Int(type)]
        guard let getLength = apis.markerLength, let getBytes = apis.markerBytes else {
            result["serialization_status"] = "api_unavailable"
            warning("Public text-marker byte accessors are unavailable at runtime; the native marker type is retained.")
            return result
        }
        let length = getLength(value)
        result["byte_length"] = length
        guard length >= 0 else {
            result["serialization_status"] = "invalid_byte_length"
            warning("AXTextMarkerGetLength returned a negative byte length.")
            return result
        }
        // An empty payload needs no pointer dereference. A nonempty payload
        // must have a valid byte pointer while its retained CF object is alive.
        if length == 0 {
            result["bytes_base64"] = ""
        } else if let bytes = getBytes(value) {
            result["bytes_base64"] = Data(bytes: bytes, count: length).base64EncodedString()
        } else {
            result["serialization_status"] = "missing_byte_pointer"
            warning("AXTextMarkerGetBytePtr returned no pointer for a nonempty marker.")
            return result
        }
        result["serialization_status"] = "captured"
        return result
    }

    static func encode(_ value: CFTypeRef, type: CFTypeID, apis: APIs = native, warning: (String) -> Void) -> [String: Any]? {
        if let getMarkerID = apis.markerTypeID, type == getMarkerID() {
            return marker(value, type: type, apis: apis, warning: warning)
        }
        guard let getRangeID = apis.rangeTypeID, type == getRangeID() else { return nil }
        var result: [String: Any] = ["type": "AXTextMarkerRange", "cf_type_id": Int(type)]
        var complete = true
        for (name, copy) in [("start", apis.copyStart), ("end", apis.copyEnd)] {
            guard let copy else {
                result[name] = ["serialization_status": "api_unavailable"]
                warning("Public text-marker range \(name) accessor is unavailable at runtime.")
                complete = false
                continue
            }
            guard let retained = copy(value) else {
                result[name] = ["serialization_status": "missing_endpoint"]
                warning("Public text-marker range \(name) accessor returned no endpoint.")
                complete = false
                continue
            }
            // Copy functions return owned CF objects. Keep each endpoint alive
            // until its bytes are copied, then allow ARC to release it once.
            let endpoint = retained.takeRetainedValue()
            let endpointType = CFGetTypeID(endpoint)
            guard let getMarkerID = apis.markerTypeID, endpointType == getMarkerID() else {
                result[name] = ["serialization_status": "unexpected_endpoint_type", "cf_type_id": Int(endpointType)]
                warning("Public text-marker range \(name) accessor returned an unrecognized endpoint type.")
                complete = false
                continue
            }
            let encoded = marker(endpoint, type: endpointType, apis: apis, warning: warning)
            result[name] = encoded
            if encoded["serialization_status"] as? String != "captured" { complete = false }
        }
        result["serialization_status"] = complete ? "captured" : "partial"
        return result
    }

    // Entirely offline: construct CF marker objects using public APIs. No app
    // process, Accessibility permission, or native UI element is accessed.
    static func selfTest() throws -> Int {
        guard let createMarker = symbol("AXTextMarkerCreate", as: CreateMarkerFunction.self),
              let createRange = symbol("AXTextMarkerRangeCreate", as: CreateRangeFunction.self) else {
            throw EngineError.message("Offline text-marker fixtures require public marker constructor APIs.")
        }
        func makeMarker(_ bytes: [UInt8]) throws -> CFTypeRef {
            // Supply a valid pointer even for a zero-length payload.
            let storage = bytes.isEmpty ? [UInt8(0)] : bytes
            guard let marker = storage.withUnsafeBufferPointer({ createMarker(nil, $0.baseAddress!, bytes.count) }) else {
                throw EngineError.message("Cannot construct offline text-marker fixture.")
            }
            return marker.takeRetainedValue()
        }
        func check(_ condition: Bool, _ message: String) throws {
            if !condition { throw EngineError.message("Offline text-marker fixture failed: \(message)") }
        }
        var passed = 0
        for bytes in [[UInt8(0)], Array(UInt8.min...UInt8.max)] {
            let object = try makeMarker(bytes)
            var warnings: [String] = []
            let value = encode(object, type: CFGetTypeID(object)) { warnings.append($0) }
            try check(value?["type"] as? String == "AXTextMarker" &&
                      value?["byte_length"] as? Int == bytes.count &&
                      value?["bytes_base64"] as? String == Data(bytes).base64EncodedString() &&
                      value?["serialization_status"] as? String == "captured" && warnings.isEmpty,
                      "marker bytes must round-trip exactly, including NUL and non-UTF8 data")
            passed += 1
        }
        let startBytes: [UInt8] = [0, 128, 255]
        let endBytes: [UInt8] = [254, 1, 0, 34]
        let start = try makeMarker(startBytes)
        let end = try makeMarker(endBytes)
        // The public constructor on this OS rejects empty payloads. Exercise
        // the valid zero-length accessor branch without inventing an app read.
        var emptyPayload = native
        emptyPayload.markerLength = { _ in 0 }
        emptyPayload.markerBytes = { _ in nil }
        var emptyWarnings: [String] = []
        let empty = encode(start, type: CFGetTypeID(start), apis: emptyPayload) { emptyWarnings.append($0) }
        try check(empty?["byte_length"] as? Int == 0 && empty?["bytes_base64"] as? String == "" &&
                  empty?["serialization_status"] as? String == "captured" && emptyWarnings.isEmpty,
                  "empty payload never dereferences a missing pointer")
        passed += 1
        guard let rangeOwned = createRange(nil, start, end) else {
            throw EngineError.message("Cannot construct offline text-marker range fixture.")
        }
        let range = rangeOwned.takeRetainedValue()
        var warnings: [String] = []
        let value = encode(range, type: CFGetTypeID(range)) { warnings.append($0) }
        let encodedStart = value?["start"] as? [String: Any]
        let encodedEnd = value?["end"] as? [String: Any]
        try check(JSONSerialization.isValidJSONObject(value ?? [:]) &&
                  value?["serialization_status"] as? String == "captured" && warnings.isEmpty &&
                  encodedStart?["bytes_base64"] as? String == Data(startBytes).base64EncodedString() &&
                  encodedEnd?["bytes_base64"] as? String == Data(endBytes).base64EncodedString(),
                  "range preserves both ordered endpoint payloads")
        passed += 1
        let string = "not a marker" as CFString
        try check(encode(string, type: CFGetTypeID(string)) { warnings.append($0) } == nil && warnings.isEmpty,
                  "unrelated CF types must not be classified as text markers")
        passed += 1
        var unavailable = native
        unavailable.markerBytes = nil
        warnings = []
        let missingBytes = encode(start, type: CFGetTypeID(start), apis: unavailable) { warnings.append($0) }
        try check(missingBytes?["serialization_status"] as? String == "api_unavailable" && warnings.count == 1,
                  "unavailable byte API stays explicit")
        passed += 1
        unavailable = native
        unavailable.copyEnd = nil
        warnings = []
        let missingEnd = encode(range, type: CFGetTypeID(range), apis: unavailable) { warnings.append($0) }
        let retainedStart = missingEnd?["start"] as? [String: Any]
        try check(missingEnd?["serialization_status"] as? String == "partial" && warnings.count == 1 &&
                  retainedStart?["bytes_base64"] as? String == Data(startBytes).base64EncodedString(),
                  "missing endpoint API preserves the other endpoint and exposes the gap")
        passed += 1
        return passed
    }
}


_ = AXUIElementGetTypeID()
print("NativeTextCodec offline fixtures:", try NativeTextCodec.selfTest())
