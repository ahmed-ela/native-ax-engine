import AppKit
import ApplicationServices
import Foundation
enum EngineError: Error { case message(String) }
enum NativeGraphicsCodec {
    static func bits(_ value: CGFloat) -> String { String(format: "%016llx", Double(value).bitPattern) }

    static func number(_ value: CGFloat) -> Any {
        let scalar = Double(value)
        if scalar.isFinite { return scalar }
        return ["type": "nonfinite_number",
                "value": scalar.isNaN ? "nan" : (scalar.sign == .minus ? "-infinity" : "infinity"),
                "ieee754_binary64": String(format: "%016llx", scalar.bitPattern)]
    }

    static func modelName(_ model: CGColorSpaceModel) -> String {
        switch model {
        case .unknown: return "unknown"
        case .monochrome: return "monochrome"
        case .rgb: return "rgb"
        case .cmyk: return "cmyk"
        case .lab: return "lab"
        case .deviceN: return "device_n"
        case .indexed: return "indexed"
        case .pattern: return "pattern"
        case .XYZ: return "xyz"
        @unknown default: return "unrecognized"
        }
    }

    static func colorSpace(_ space: CGColorSpace, ancestors: Set<UInt> = [], warning: (String) -> Void) -> ([String: Any], Bool) {
        let address = UInt(bitPattern: Unmanaged.passUnretained(space).toOpaque())
        var record: [String: Any] = ["type": "CGColorSpace", "cf_type_id": Int(CGColorSpace.typeID),
                                     "model": ["name": modelName(space.model), "raw_value": space.model.rawValue],
                                     "component_count": space.numberOfComponents]
        guard !ancestors.contains(address) else {
            record["serialization_status"] = "cyclic_base_color_space"
            warning("Native color space has a cyclic base-color-space reference; no synthetic definition was supplied.")
            return (record, false)
        }
        var complete = true
        var visited = ancestors
        visited.insert(address)
        if let name = space.name {
            record["name"] = name as String
            record["name_status"] = "captured"
        } else {
            record["name"] = NSNull()
            record["name_status"] = "not_named"
        }
        if #available(macOS 10.12, *) {
            if let nativeData = space.copyICCData() {
                let data = nativeData as Data
                record["icc_profile"] = ["status": "captured", "byte_length": data.count,
                                          "bytes_base64": data.base64EncodedString()]
            } else {
                // Apple documents NULL as a color space with no ICC profile.
                record["icc_profile"] = ["status": "not_present"]
            }
        } else {
            record["icc_profile"] = ["status": "api_unavailable"]
            warning("Public ICC-profile accessor is unavailable on this macOS version.")
            complete = false
        }
        if space.model == .indexed || space.model == .pattern {
            if let base = space.baseColorSpace {
                let (encoded, resolved) = colorSpace(base, ancestors: visited, warning: warning)
                record["base_color_space"] = encoded
                if !resolved { complete = false }
                if space.model == .indexed {
                    if let table = space.colorTable {
                        record["color_table"] = ["status": "captured", "byte_length": table.count,
                                                  "bytes_base64": Data(table).base64EncodedString()]
                        if base.numberOfComponents > 0 && table.count % base.numberOfComponents == 0 {
                            record["color_table_entry_count"] = table.count / base.numberOfComponents
                        } else {
                            record["color_table_entry_count"] = NSNull()
                            warning("Native indexed color table length cannot be divided by the base color space's component count.")
                            complete = false
                        }
                    } else {
                        record["color_table"] = ["status": "not_present"]
                        warning("Native indexed color space returned no public color table.")
                        complete = false
                    }
                }
            } else {
                record["base_color_space"] = ["status": "not_present"]
                if space.model == .indexed {
                    warning("Native indexed color space returned no required base color space; its color table is unresolved.")
                    record["color_table"] = ["status": "missing_base_color_space"]
                    complete = false
                }
            }
        } else if space.name == nil && (record["icc_profile"] as? [String: Any])?["status"] as? String != "captured" {
            // Components and model alone cannot describe an arbitrary unnamed
            // calibrated space. Preserve the gap rather than invent a profile.
            warning("Unnamed native color space has no public ICC definition; model and components alone may not reconstruct its color semantics.")
            complete = false
        }
        if space.model == .unknown || modelName(space.model) == "unrecognized" {
            warning("Native color space model is unknown; its raw model value is retained.")
            complete = false
        }
        record["serialization_status"] = complete ? "captured" : "partial"
        return (record, complete)
    }

    static func color(_ color: CGColor, warning: (String) -> Void) -> [String: Any] {
        var result: [String: Any] = ["type": "CGColor", "cf_type_id": Int(CGColor.typeID),
                                    "component_count": color.numberOfComponents, "alpha": number(color.alpha),
                                    "alpha_ieee754_binary64": bits(color.alpha)]
        var complete = true
        if let components = color.components {
            result["components"] = components.map(number)
            result["components_ieee754_binary64"] = components.map(bits)
            if components.count != color.numberOfComponents {
                warning("Native color component array count differs from CGColorGetNumberOfComponents.")
                complete = false
            }
        } else {
            result["components"] = NSNull()
            result["components_status"] = "missing_components"
            warning("CGColorGetComponents returned no native components.")
            complete = false
        }
        if let space = color.colorSpace {
            let (encoded, resolved) = colorSpace(space, warning: warning)
            result["color_space"] = encoded
            if !resolved { complete = false }
        } else {
            result["color_space"] = ["status": "not_present"]
            warning("Native color returned no color space; its component semantics are unresolved.")
            complete = false
        }
        if let pattern = color.pattern {
            result["pattern"] = ["type": "CGPattern", "cf_type_id": Int(CGPattern.typeID),
                                  "serialization_status": "opaque_drawing_callback"]
            // Public CGPattern APIs do not expose the constructor's drawing
            // callback, private info payload, or tile definition for inspection.
            _ = pattern
            warning("Native pattern color contains a drawing callback that public APIs cannot serialize; raw color components and color space are retained.")
            complete = false
        }
        result["serialization_status"] = complete ? "captured" : "partial"
        return result
    }

    static func path(_ path: CGPath, warning: (String) -> Void) -> [String: Any] {
        var commands: [[String: Any]] = []
        var complete = true
        path.applyWithBlock { pointer in
            let element = pointer.pointee
            let command: String
            let pointCount: Int
            switch element.type {
            case .moveToPoint: command = "move_to"; pointCount = 1
            case .addLineToPoint: command = "line_to"; pointCount = 1
            case .addQuadCurveToPoint: command = "quad_curve_to"; pointCount = 2
            case .addCurveToPoint: command = "cubic_curve_to"; pointCount = 3
            case .closeSubpath: command = "close_subpath"; pointCount = 0
            @unknown default:
                commands.append(["command": "unrecognized", "native_type": element.type.rawValue,
                                 "points_status": "unknown_command_arity"])
                warning("Native CGPath command has an unknown type; its point count was not guessed.")
                complete = false
                return
            }
            let points: [[String: Any]] = (0..<pointCount).map { index in
                let point = element.points[index]
                return ["x": number(point.x), "y": number(point.y),
                        "x_ieee754_binary64": bits(point.x), "y_ieee754_binary64": bits(point.y)]
            }
            commands.append(["command": command, "native_type": element.type.rawValue, "points": points])
        }
        return ["type": "CGPath", "cf_type_id": Int(CGPath.typeID), "commands": commands,
                "command_count": commands.count, "is_empty": path.isEmpty,
                "serialization_status": complete ? "captured" : "partial"]
    }

    static func encode(_ value: CFTypeRef, type: CFTypeID, warning: (String) -> Void) -> [String: Any]? {
        // Swift's .typeID properties call the public GetTypeID functions. Their
        // runtime values are compared, never numeric IDs from an older export.
        if type == CGColor.typeID { return color(value as! CGColor, warning: warning) }
        if type == CGPath.typeID { return path(value as! CGPath, warning: warning) }
        return nil
    }

    static func selfTest() throws -> Int {
        func check(_ condition: Bool, _ message: String) throws {
            if !condition { throw EngineError.message("Offline graphics fixture failed: \(message)") }
        }
        var passed = 0
        var warnings: [String] = []
        let rgb = CGColor(red: 0.125, green: 0.25, blue: 0.75, alpha: 0.5)
        let rgbRecord = encode(rgb, type: CFGetTypeID(rgb)) { warnings.append($0) }!
        let rgbSpace = rgbRecord["color_space"] as? [String: Any]
        let rgbModel = rgbSpace?["model"] as? [String: Any]
        try check(rgbRecord["components"] as? [Double] == [0.125, 0.25, 0.75, 0.5] &&
                  rgbModel?["name"] as? String == "rgb" && warnings.isEmpty && JSONSerialization.isValidJSONObject(rgbRecord),
                  "RGB color preserves native components, alpha, and model without conversion")
        passed += 1
        let profile = rgbSpace?["icc_profile"] as? [String: Any]
        let originalProfile = rgb.colorSpace!.copyICCData()! as Data
        try check(rgbSpace?["name"] as? String == rgb.colorSpace!.name! as String &&
                  profile?["bytes_base64"] as? String == originalProfile.base64EncodedString() &&
                  profile?["byte_length"] as? Int == originalProfile.count,
                  "named color space and ICC bytes are preserved exactly")
        passed += 1
        let gray = CGColor(gray: 0.375, alpha: 0.625)
        warnings = []
        let grayRecord = encode(gray, type: CFGetTypeID(gray)) { warnings.append($0) }!
        try check(grayRecord["components"] as? [Double] == [0.375, 0.625] && warnings.isEmpty,
                  "monochrome components retain their native arity")
        passed += 1
        let empty = CGMutablePath()
        warnings = []
        let emptyRecord = encode(empty, type: CFGetTypeID(empty)) { warnings.append($0) }!
        try check(emptyRecord["is_empty"] as? Bool == true && emptyRecord["command_count"] as? Int == 0 && warnings.isEmpty,
                  "empty native path has no invented commands")
        passed += 1
        let fixture = CGMutablePath()
        fixture.move(to: CGPoint(x: 0.125, y: -0.25))
        fixture.addLine(to: CGPoint(x: 2.5, y: 3.75))
        fixture.addQuadCurve(to: CGPoint(x: 6, y: 7), control: CGPoint(x: 4, y: 5))
        fixture.addCurve(to: CGPoint(x: 12, y: 13), control1: CGPoint(x: 8, y: 9), control2: CGPoint(x: 10, y: 11))
        fixture.closeSubpath()
        fixture.move(to: CGPoint(x: -4, y: -5))
        warnings = []
        let pathRecord = encode(fixture, type: CFGetTypeID(fixture)) { warnings.append($0) }!
        let commands = pathRecord["commands"] as? [[String: Any]] ?? []
        try check(commands.compactMap { $0["command"] as? String } ==
                  ["move_to", "line_to", "quad_curve_to", "cubic_curve_to", "close_subpath", "move_to"] && warnings.isEmpty,
                  "native path command ordering and subpath boundaries are unchanged")
        passed += 1
        func coordinates(_ command: [String: Any]) -> [[String: Double]] {
            (command["points"] as? [[String: Any]] ?? []).map { ["x": $0["x"] as! Double, "y": $0["y"] as! Double] }
        }
        try check(coordinates(commands[2]) == [["x": 4, "y": 5], ["x": 6, "y": 7]] &&
                  coordinates(commands[3]) == [["x": 8, "y": 9], ["x": 10, "y": 11], ["x": 12, "y": 13]] &&
                  coordinates(commands[4]) == [],
                  "curve control points and endpoint arities are preserved without flattening")
        passed += 1
        try check(JSONSerialization.isValidJSONObject(pathRecord), "native path output is JSON serializable")
        passed += 1
        let unrelated = "not graphics" as CFString
        try check(encode(unrelated, type: CFGetTypeID(unrelated)) { warnings.append($0) } == nil && warnings.isEmpty,
                  "unrelated CF types do not match runtime graphics type IDs")
        passed += 1
        let nonfinite = [CGFloat.nan, CGFloat.infinity, -CGFloat.infinity].map(number)
        try check(nonfinite.compactMap { ($0 as? [String: Any])?["value"] as? String } == ["nan", "infinity", "-infinity"] &&
                  nonfinite.allSatisfy { (($0 as? [String: Any])?["ieee754_binary64"] as? String)?.count == 16 } &&
                  JSONSerialization.isValidJSONObject(nonfinite),
                  "nonfinite numbers retain their kinds and binary64 bits without invalid JSON")
        passed += 1
        let signedZero = CGMutablePath()
        signedZero.move(to: CGPoint(x: -CGFloat.zero, y: CGFloat.zero))
        let zeroRecord = encode(signedZero, type: CFGetTypeID(signedZero)) { warnings.append($0) }!
        let zeroCommands = zeroRecord["commands"] as? [[String: Any]] ?? []
        let zeroPoint = (zeroCommands.first?["points"] as? [[String: Any]])?.first
        var nativeZeroX = ""
        var nativeZeroY = ""
        signedZero.applyWithBlock { pointer in
            nativeZeroX = bits(pointer.pointee.points[0].x)
            nativeZeroY = bits(pointer.pointee.points[0].y)
        }
        // CoreGraphics may normalize input -0 when storing the path. Match the
        // actual native callback values, while testing the codec's -0 handling
        // directly so no value is invented to match a constructor argument.
        try check(bits(-CGFloat.zero) == "8000000000000000" &&
                  zeroPoint?["x_ieee754_binary64"] as? String == nativeZeroX &&
                  zeroPoint?["y_ieee754_binary64"] as? String == nativeZeroY &&
                  rgbRecord["components_ieee754_binary64"] as? [String] == rgb.components!.map(bits),
                  "finite coordinates and color components retain exact bits, including signed zero")
        passed += 1
        let table: [UInt8] = [0, 128, 255, 64, 32, 16]
        guard let indexed = table.withUnsafeBufferPointer({
            CGColorSpace(indexedBaseSpace: CGColorSpaceCreateDeviceRGB(), last: 1, colorTable: $0.baseAddress!)
        }), let indexedColor = CGColor(colorSpace: indexed, components: [1, 0.5]) else {
            throw EngineError.message("Cannot construct offline indexed color fixture.")
        }
        warnings = []
        let indexedRecord = encode(indexedColor, type: CFGetTypeID(indexedColor)) { warnings.append($0) }!
        let indexedSpace = indexedRecord["color_space"] as? [String: Any]
        let indexedTable = indexedSpace?["color_table"] as? [String: Any]
        try check(indexedTable?["bytes_base64"] as? String == Data(table).base64EncodedString() &&
                  indexedSpace?["color_table_entry_count"] as? Int == 2 &&
                  indexedRecord["components"] as? [Double] == [1, 0.5] && warnings.isEmpty,
                  "indexed colors retain their base space, native index, and exact color-table bytes")
        passed += 1
        var callbacks = CGPatternCallbacks(version: 0, drawPattern: { _, _ in }, releaseInfo: nil)
        guard let pattern = CGPattern(info: nil, bounds: CGRect(x: 0, y: 0, width: 1, height: 1),
                                      matrix: .identity, xStep: 1, yStep: 1, tiling: .constantSpacing,
                                      isColored: true, callbacks: &callbacks),
              let patternSpace = CGColorSpace(patternBaseSpace: nil),
              let patternColor = CGColor(patternSpace: patternSpace, pattern: pattern, components: [1]) else {
            throw EngineError.message("Cannot construct offline pattern color fixture.")
        }
        warnings = []
        let patternRecord = encode(patternColor, type: CFGetTypeID(patternColor)) { warnings.append($0) }!
        let patternValue = patternRecord["pattern"] as? [String: Any]
        try check(patternRecord["serialization_status"] as? String == "partial" && warnings.count == 1 &&
                  patternValue?["serialization_status"] as? String == "opaque_drawing_callback" &&
                  patternRecord["components"] as? [Double] == [1],
                  "publicly inaccessible pattern definition stays explicit while accessible values remain captured")
        passed += 1
        let payloadNaN = CGFloat(Double(bitPattern: 0x7ff8000000000042))
        let payloadRecord = number(payloadNaN) as? [String: Any]
        try check(payloadRecord?["ieee754_binary64"] as? String == "7ff8000000000042",
                  "nonfinite payload bits are retained without normalization")
        passed += 1
        return passed
    }
}


print("NativeGraphicsCodec offline fixtures:", try NativeGraphicsCodec.selfTest())
