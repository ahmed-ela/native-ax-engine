import Foundation
import ApplicationServices
enum EngineError: Error { case message(String) }
let retryLimit = 2
func jsonData(_ object: Any, pretty: Bool = false) throws -> Data {
    try JSONSerialization.data(withJSONObject: object, options: pretty ? [.sortedKeys, .prettyPrinted] : [.sortedKeys])
}
func canonical(_ object: Any) -> String {
    guard let data = try? jsonData(object), let text = String(data: data, encoding: .utf8) else { return "null" }
    return text
}

func errorName(_ error: AXError) -> String {
    switch error {
    case .success: return "success"
    case .failure: return "failure"
    case .illegalArgument: return "illegalArgument"
    case .invalidUIElement: return "invalidUIElement"
    case .invalidUIElementObserver: return "invalidUIElementObserver"
    case .cannotComplete: return "cannotComplete"
    case .attributeUnsupported: return "attributeUnsupported"
    case .actionUnsupported: return "actionUnsupported"
    case .notificationUnsupported: return "notificationUnsupported"
    case .notImplemented: return "notImplemented"
    case .notificationAlreadyRegistered: return "notificationAlreadyRegistered"
    case .notificationNotRegistered: return "notificationNotRegistered"
    case .apiDisabled: return "apiDisabled"
    case .noValue: return "noValue"
    case .parameterizedAttributeUnsupported: return "parameterizedAttributeUnsupported"
    case .notEnoughPrecision: return "notEnoughPrecision"
    @unknown default: return "unknown"
    }
}

struct ReadResult<T> {
    let value: T?
    let error: AXError
    let attempts: Int
    var recovery: [String: Any]? = nil
    var status: [String: Any] {
        var result: [String: Any] = ["code": error.rawValue, "name": errorName(error), "attempts": attempts]
        if let recovery { result["native_read_recovery"] = recovery }
        return result
    }
}

func nativeReadStatus<T>(_ result: ReadResult<T>) -> [String: Any] {
    ["code": result.error.rawValue, "name": errorName(result.error), "attempts": result.attempts]
}

func nativeMetadataRecoveryEligible(_ error: AXError) -> Bool {
    error == .failure || error == .cannotComplete || error == .attributeUnsupported
}

func read<T>(_ operation: (inout T?) -> AXError) -> ReadResult<T> {
    var finalError = AXError.failure
    var finalValue: T?
    var attempts = 0
    for _ in 0...retryLimit {
        attempts += 1
        finalValue = nil
        finalError = operation(&finalValue)
        if finalError != .cannotComplete { break }
    }
    return ReadResult(value: finalValue, error: finalError, attempts: attempts)
}

func recoverNativeArray(_ initial: ReadResult<CFTypeRef>,
                        count: () -> ReadResult<NSNumber>,
                        values: (Int, Int) -> ReadResult<CFArray>) -> ReadResult<CFTypeRef> {
    // A failed read is never relabeled as an empty selection. Recovery needs
    // successful native array-count and page reads, with the count checked
    // again afterwards. The original failure remains in the recovery trace.
    guard nativeMetadataRecoveryEligible(initial.error) else { return initial }
    var trace: [String: Any] = ["method": "AXUIElementGetAttributeValueCount/AXUIElementCopyAttributeValues",
                              "initial_status": nativeReadStatus(initial), "resolved": false, "resolution_kind": "unresolved"]
    func failed(_ reason: String) -> ReadResult<CFTypeRef> {
        trace["reason"] = reason
        return ReadResult(value: initial.value, error: initial.error, attempts: initial.attempts, recovery: trace)
    }
    let before = count()
    trace["count_before_status"] = before.status
    guard before.error == .success, let beforeValue = before.value else { return failed("Native array count could not be read.") }
    let expected = beforeValue.intValue
    trace["count_before"] = expected
    guard expected >= 0 else { return failed("Native array count was negative.") }
    var result: [Any] = [], pages: [[String: Any]] = []
    while result.count < expected {
        let start = result.count, requested = min(256, expected - start)
        let page = values(start, requested)
        let items = page.value as? [Any]
        pages.append(["index": start, "requested": requested, "status": page.status,
                      "has_value": page.value != nil, "returned_count": items?.count ?? NSNull()])
        trace["pages"] = pages
        guard page.error == .success, let array = items, array.count == requested else {
            return failed("Native array page failed or its length changed during reading.")
        }
        result.append(contentsOf: array)
    }
    let after = count()
    trace["count_after_status"] = after.status
    trace["count_after"] = after.value ?? NSNull()
    guard after.error == .success, after.value?.intValue == expected else {
        return failed("Native array count changed or could not be confirmed after reading.")
    }
    trace["resolved"] = true
    trace["resolution_kind"] = "value"
    trace["returned_count"] = result.count
    return ReadResult(value: result as CFArray, error: .success, attempts: initial.attempts, recovery: trace)
}

func attribute(_ element: AXUIElement, _ name: String) -> ReadResult<CFTypeRef> {
    read { AXUIElementCopyAttributeValue(element, name as CFString, &$0) }
}

func nativeScalarExpectedValueKind(_ attribute: String) -> String? {
    // AXFrame's CGRect contract is the observed native frame shape; the other
    // four names and their types are defined in the public AX SDK headers.
    ["AXGrowArea": "AXUIElement", "AXTopLevelUIElement": "AXUIElement", "AXFrame": "CGRect",
     "AXPosition": "CGPoint", "AXSize": "CGSize"][attribute]
}

func nativeScalarValueValidation(_ attribute: String, _ value: CFTypeRef?) -> [String: Any] {
    let expected = nativeScalarExpectedValueKind(attribute) ?? "unknown"
    let expectedType = expected == "AXUIElement" ? AXUIElementGetTypeID() : AXValueGetTypeID()
    var result: [String: Any] = ["expected_value_kind": expected, "expected_cf_type_id": Int(expectedType),
                               "has_value": value != nil, "cf_type_id": NSNull(), "ax_value_type": NSNull(),
                               "ax_value_decoded": NSNull(), "valid": false]
    guard let value else { result["reason"] = "Native scalar query returned no value."; return result }
    let type = CFGetTypeID(value)
    result["cf_type_id"] = Int(type)
    if type == AXValueGetTypeID() {
        let native = value as! AXValue
        let subtype = AXValueGetType(native)
        let subtypeName: String
        switch subtype {
        case .cgPoint: subtypeName = "cgPoint"
        case .cgSize: subtypeName = "cgSize"
        case .cgRect: subtypeName = "cgRect"
        case .cfRange: subtypeName = "cfRange"
        case .axError: subtypeName = "axError"
        case .illegal: subtypeName = "illegal"
        @unknown default: subtypeName = "unknown"
        }
        result["ax_value_type"] = subtypeName
        var decoded: Bool?
        if expected == "CGPoint", subtype == .cgPoint {
            var point = CGPoint.zero; decoded = AXValueGetValue(native, .cgPoint, &point)
        } else if expected == "CGSize", subtype == .cgSize {
            var size = CGSize.zero; decoded = AXValueGetValue(native, .cgSize, &size)
        } else if expected == "CGRect", subtype == .cgRect {
            var rect = CGRect.zero; decoded = AXValueGetValue(native, .cgRect, &rect)
        }
        if let decoded { result["ax_value_decoded"] = decoded }
        result["valid"] = type == expectedType && decoded == true
    } else {
        result["valid"] = expected == "AXUIElement" && type == expectedType
    }
    if result["valid"] as? Bool != true { result["reason"] = "Native value does not match the known scalar type contract." }
    return result
}

struct NativeValuePathResult {
    let value: CFTypeRef?
    let steps: [[String: Any]]
    let resolved: Bool
    let reason: String?
}

func nativeValueAtPath(_ initial: CFTypeRef?, components: [Any]) -> NativeValuePathResult {
    guard var selected = initial else { return NativeValuePathResult(value: nil, steps: [], resolved: false, reason: "Attribute read returned no native value.") }
    var steps: [[String: Any]] = []
    for component in components {
        let containerType = CFGetTypeID(selected)
        var step: [String: Any] = ["component_kind": "unsupported", "container_cf_type_id": Int(containerType),
                                  "selected_has_value": false, "resolved": false]
        var next: CFTypeRef?
        if CFGetTypeID(component as CFTypeRef) != CFBooleanGetTypeID(), let index = component as? Int {
            step["component_kind"] = "array_index"; step["index"] = index
            if containerType == CFArrayGetTypeID(), let items = selected as? [Any], index >= 0, index < items.count {
                next = items[index] as CFTypeRef
            }
        } else if let key = component as? String {
            step["component_kind"] = "dictionary_key"; step["key"] = key
            if containerType == CFDictionaryGetTypeID(), let object = selected as? [String: Any], let value = object[key] {
                next = value as CFTypeRef
            }
        }
        step["selected_has_value"] = next != nil
        step["resolved"] = next != nil
        if next == nil { step["reason"] = "Recorded value-path component is unsupported, absent, out of range, or has the wrong native container type." }
        steps.append(step)
        guard let next else { return NativeValuePathResult(value: nil, steps: steps, resolved: false, reason: step["reason"] as? String) }
        selected = next
    }
    return NativeValuePathResult(value: selected, steps: steps, resolved: true, reason: nil)
}

struct NativeScalarRefreshResult {
    let element: AXUIElement?
    let evidence: [String: Any]
}

func refreshNativeScalarTarget(selectorPath: [[String: Any]], rootPID: pid_t, expectedPID: pid_t,
                               recordedAtPath: ([[String: Any]]) -> (element: AXUIElement, pid: pid_t)?,
                               processMatches: (pid_t) -> Bool, createRoot: () -> AXUIElement,
                               setTimeout: (AXUIElement) -> AXError,
                               readAttribute: (AXUIElement, String) -> ReadResult<CFTypeRef>,
                               elementPID: (AXUIElement) -> ReadResult<NSNumber>,
                               sameElement: (AXUIElement, AXUIElement) -> Bool = { CFEqual($0, $1) }) -> NativeScalarRefreshResult {
    var evidence: [String: Any] = ["attempted": true, "selector_path": selectorPath, "root_pid": Int(rootPID),
                                 "expected_pid": Int(expectedPID), "process_identity_matches": false,
                                 "root_same_element": false, "root_timeout_status": NSNull(), "steps": [],
                                 "same_element": false, "pid_status": NSNull(), "pid": NSNull(), "resolved": false]
    func failed(_ reason: String) -> NativeScalarRefreshResult {
        evidence["reason"] = reason
        return NativeScalarRefreshResult(element: nil, evidence: evidence)
    }
    guard processMatches(rootPID), processMatches(expectedPID) else { return failed("Recorded root or owner process/launch identity changed.") }
    evidence["process_identity_matches"] = true
    guard let recordedRoot = recordedAtPath([]), recordedRoot.pid == rootPID else { return failed("Recorded native root identity is unavailable.") }
    var current = createRoot()
    evidence["root_same_element"] = sameElement(current, recordedRoot.element)
    guard evidence["root_same_element"] as? Bool == true else { return failed("Fresh native root is not CFEqual to the recorded root.") }
    let timeout = setTimeout(current)
    evidence["root_timeout_status"] = nativeReadStatus(ReadResult<CFTypeRef>(value: nil, error: timeout, attempts: 1))
    guard timeout == .success else { return failed("Fresh native root request timeout could not be set.") }
    var steps: [[String: Any]] = []
    for (index, selector) in selectorPath.enumerated() {
        var step: [String: Any] = ["step": index, "query_status": NSNull(), "has_value": false,
                                  "path_steps": [], "selected_cf_type_id": NSNull(), "selected_is_element": false,
                                  "same_element": false, "pid_status": NSNull(), "pid": NSNull(),
                                  "process_identity_matches": NSNull(), "resolved": false]
        guard let attribute = selector["attribute"] as? String, let components = selector["value_path"] as? [Any] else {
            steps.append(step); evidence["steps"] = steps
            return failed("Recorded native selector path is malformed.")
        }
        step["attribute"] = attribute; step["value_path"] = components
        let read = readAttribute(current, attribute)
        step["query_status"] = nativeReadStatus(read); step["has_value"] = read.value != nil
        guard read.error == .success else {
            steps.append(step); evidence["steps"] = steps
            return failed("Fresh native selector attribute read failed.")
        }
        let selected = nativeValueAtPath(read.value, components: components)
        step["path_steps"] = selected.steps
        if let value = selected.value { step["selected_cf_type_id"] = Int(CFGetTypeID(value)) }
        guard selected.resolved, let value = selected.value, CFGetTypeID(value) == AXUIElementGetTypeID() else {
            steps.append(step); evidence["steps"] = steps
            return failed(selected.reason ?? "Fresh selector did not return an actual native element.")
        }
        step["selected_is_element"] = true
        let element = value as! AXUIElement
        let prefix = Array(selectorPath.prefix(index + 1))
        guard let recorded = recordedAtPath(prefix) else {
            steps.append(step); evidence["steps"] = steps
            return failed("Recorded native element for a selector prefix is unavailable.")
        }
        step["same_element"] = sameElement(element, recorded.element)
        step["expected_pid"] = Int(recorded.pid)
        let pidRead = elementPID(element)
        step["pid_status"] = nativeReadStatus(pidRead); step["pid"] = pidRead.value ?? NSNull()
        if pidRead.error == .success, pidRead.value?.int32Value == recorded.pid {
            step["process_identity_matches"] = processMatches(recorded.pid)
        }
        guard step["same_element"] as? Bool == true, pidRead.error == .success,
              pidRead.value?.int32Value == recorded.pid, step["process_identity_matches"] as? Bool == true else {
            if step["process_identity_matches"] as? Bool == false { evidence["process_identity_matches"] = false }
            steps.append(step); evidence["steps"] = steps
            return failed("Fresh selector reference, PID, or process launch identity differs from the recorded prefix.")
        }
        step["resolved"] = true
        steps.append(step); evidence["steps"] = steps; current = element
    }
    guard let recorded = recordedAtPath(selectorPath) else { return failed("Recorded scalar owner is unavailable.") }
    evidence["same_element"] = sameElement(current, recorded.element)
    let pidRead = elementPID(current)
    evidence["pid_status"] = nativeReadStatus(pidRead); evidence["pid"] = pidRead.value ?? NSNull()
    guard evidence["same_element"] as? Bool == true, recorded.pid == expectedPID,
          pidRead.error == .success, pidRead.value?.int32Value == expectedPID,
          processMatches(rootPID), processMatches(expectedPID) else {
        evidence["process_identity_matches"] = processMatches(rootPID) && processMatches(expectedPID)
        return failed("Fresh scalar owner no longer has the exact recorded element, PID, or process launch identity.")
    }
    evidence["resolved"] = true
    return NativeScalarRefreshResult(element: current, evidence: evidence)
}

// A menu wrapper can be recreated while the capture still retains the original
// native owner. This predicate permits querying that original owner only when
// CFEqual is the sole failure of the fresh prefix; it never follows a changed
// prefix or treats a read/PID/process/type failure as an identity mismatch.
func nativeScalarRetainedReferenceEligible(_ refresh: [String: Any]) -> Bool {
    guard refresh["attempted"] as? Bool == true, refresh["resolved"] as? Bool == false,
          refresh["root_same_element"] as? Bool == true,
          refresh["process_identity_matches"] as? Bool == true,
          let timeout = refresh["root_timeout_status"] as? [String: Any],
          (timeout["code"] as? NSNumber)?.int32Value == AXError.success.rawValue,
          let selectors = refresh["selector_path"] as? [[String: Any]],
          let steps = refresh["steps"] as? [[String: Any]],
          !steps.isEmpty, steps.count <= selectors.count else { return false }
    for (index, step) in steps.enumerated() {
        let selector = selectors[index]
        guard step["step"] as? Int == index,
              let attribute = selector["attribute"] as? String, !attribute.isEmpty,
              step["attribute"] as? String == attribute,
              let components = selector["value_path"] as? [Any],
              let stepComponents = step["value_path"] as? [Any],
              canonical(components) == canonical(stepComponents),
              let paths = step["path_steps"] as? [[String: Any]], paths.count == components.count,
              paths.allSatisfy({ $0["resolved"] as? Bool == true && $0["selected_has_value"] as? Bool == true }),
              let read = step["query_status"] as? [String: Any], (read["code"] as? NSNumber)?.int32Value == AXError.success.rawValue,
              step["has_value"] as? Bool == true, step["selected_is_element"] as? Bool == true,
              step["selected_cf_type_id"] as? Int == Int(AXUIElementGetTypeID()),
              let pid = step["pid_status"] as? [String: Any], (pid["code"] as? NSNumber)?.int32Value == AXError.success.rawValue,
              let expected = step["expected_pid"] as? Int, step["pid"] as? Int == expected,
              step["process_identity_matches"] as? Bool == true else { return false }
        if index == steps.count - 1 {
            guard step["same_element"] as? Bool == false, step["resolved"] as? Bool == false else { return false }
        } else {
            guard step["same_element"] as? Bool == true, step["resolved"] as? Bool == true else { return false }
        }
    }
    return true
}

func validateRetainedNativeScalarTarget(nodeID: Int, rootID: Int, rootPID: pid_t, expectedPID: pid_t,
                                       ownerRole: String?, ownerRoleStatus: [String: Any],
                                       retainedOwner: AXUIElement,
                                       recordedAtID: (Int) -> (element: AXUIElement, pid: pid_t)?,
                                       processMatches: (pid_t) -> Bool,
                                       elementPID: (AXUIElement) -> ReadResult<NSNumber>,
                                       sameElement: (AXUIElement, AXUIElement) -> Bool = { CFEqual($0, $1) }) -> NativeScalarRefreshResult {
    var evidence: [String: Any] = ["attempted": true, "source": "capture_registry", "node_id": nodeID, "root_id": rootID,
                                  "root_pid": Int(rootPID), "expected_pid": Int(expectedPID),
                                  "owner_role": ownerRole ?? NSNull(), "owner_role_status": ownerRoleStatus,
                                  "expected_cf_type_id": Int(AXUIElementGetTypeID()), "owner_cf_type_id": Int(CFGetTypeID(retainedOwner)),
                                  "registry_binding_matches": false, "root_pid_status": NSNull(), "root_native_pid": NSNull(),
                                  "owner_pid_status": NSNull(), "owner_native_pid": NSNull(),
                                  "root_process_identity_matches": NSNull(), "owner_process_identity_matches": NSNull(), "resolved": false]
    func failed(_ reason: String) -> NativeScalarRefreshResult {
        evidence["reason"] = reason
        return NativeScalarRefreshResult(element: nil, evidence: evidence)
    }
    guard (ownerRoleStatus["code"] as? NSNumber)?.int32Value == AXError.success.rawValue,
          ownerRole == "AXMenu" || ownerRole == "AXMenuItem" else {
        return failed("Retained original-reference queries require a successful captured native menu role.")
    }
    guard let original = recordedAtID(nodeID), let root = recordedAtID(rootID),
          original.pid == expectedPID, root.pid == rootPID,
          CFGetTypeID(retainedOwner) == AXUIElementGetTypeID(), sameElement(retainedOwner, original.element) else {
        return failed("Retained query target is not the exact original capture-registry owner.")
    }
    evidence["registry_binding_matches"] = true
    evidence["root_process_identity_matches"] = processMatches(rootPID)
    evidence["owner_process_identity_matches"] = processMatches(expectedPID)
    guard evidence["root_process_identity_matches"] as? Bool == true,
          evidence["owner_process_identity_matches"] as? Bool == true else {
        return failed("Captured root or retained owner process/launch identity changed.")
    }
    let rootRead = elementPID(root.element)
    evidence["root_pid_status"] = nativeReadStatus(rootRead); evidence["root_native_pid"] = rootRead.value ?? NSNull()
    guard rootRead.error == .success, rootRead.value?.int32Value == rootPID else {
        return failed("Retained native root PID could not be confirmed.")
    }
    let ownerRead = elementPID(retainedOwner)
    evidence["owner_pid_status"] = nativeReadStatus(ownerRead); evidence["owner_native_pid"] = ownerRead.value ?? NSNull()
    guard ownerRead.error == .success, ownerRead.value?.int32Value == expectedPID else {
        return failed("Retained original native owner PID could not be confirmed.")
    }
    evidence["root_process_identity_matches"] = processMatches(rootPID)
    evidence["owner_process_identity_matches"] = processMatches(expectedPID)
    guard evidence["root_process_identity_matches"] as? Bool == true,
          evidence["owner_process_identity_matches"] as? Bool == true else {
        return failed("Captured root or retained owner process/launch identity changed during native PID validation.")
    }
    evidence["resolved"] = true
    return NativeScalarRefreshResult(element: retainedOwner, evidence: evidence)
}

func recoverNativeScalar(_ attribute: String, _ initial: ReadResult<CFTypeRef>,
                         refresh: () -> NativeScalarRefreshResult,
                         query: (AXUIElement) -> ReadResult<CFTypeRef>,
                         queryIdentityMatches: () -> Bool = { true },
                         retainedTarget: (() -> NativeScalarRefreshResult)? = nil,
                         retainedQueryValidation: ((AXUIElement) -> NativeScalarRefreshResult)? = nil) -> ReadResult<CFTypeRef> {
    guard let expected = nativeScalarExpectedValueKind(attribute), nativeMetadataRecoveryEligible(initial.error) else { return initial }
    let fresh = refresh()
    var trace: [String: Any] = ["method": "native_scalar_recovery", "initial_status": nativeReadStatus(initial),
                              "attribute": attribute, "expected_value_kind": expected,
                              "query_method": "AXUIElementCopyAttributeValue", "refresh": fresh.evidence,
                              "query_status": NSNull(), "query_process_identity_matches": NSNull(), "value_validation": NSNull(),
                              "query_target": NSNull(), "retained_reference": NSNull(), "query_retained_reference_validation": NSNull(),
                              "resolved": false, "resolution_kind": "unresolved"]
    func failed(_ reason: String) -> ReadResult<CFTypeRef> {
        trace["reason"] = reason
        return ReadResult(value: initial.value, error: initial.error, attempts: initial.attempts, recovery: trace)
    }
    let element: AXUIElement
    if fresh.evidence["resolved"] as? Bool == true, let exact = fresh.element {
        element = exact
        trace["query_target"] = "fresh_exact_reference"
    } else if attribute == "AXTopLevelUIElement", nativeScalarRetainedReferenceEligible(fresh.evidence),
              let retainedTarget, retainedQueryValidation != nil {
        let retained = retainedTarget()
        trace["retained_reference"] = retained.evidence
        guard retained.evidence["resolved"] as? Bool == true, let original = retained.element else {
            return failed("Original retained native menu owner could not be validated; no scalar query was issued.")
        }
        element = original
        trace["query_target"] = "retained_original_reference"
    } else {
        return failed("Exact native scalar owner could not be refreshed; no scalar query was issued.")
    }
    let result = query(element)
    trace["query_status"] = nativeReadStatus(result)
    let validation = nativeScalarValueValidation(attribute, result.value)
    trace["value_validation"] = validation
    trace["query_process_identity_matches"] = queryIdentityMatches()
    if trace["query_target"] as? String == "retained_original_reference", let retainedQueryValidation {
        let after = retainedQueryValidation(element)
        trace["query_retained_reference_validation"] = after.evidence
        guard after.evidence["resolved"] as? Bool == true else {
            return failed("Retained root or original menu owner failed native PID/process validation after the scalar query.")
        }
    }
    guard trace["query_process_identity_matches"] as? Bool == true else {
        return failed("Recorded root or scalar owner process/launch identity changed during the native query.")
    }
    if result.error == .noValue {
        trace["resolved"] = true; trace["resolution_kind"] = "absence"
        return ReadResult(value: nil, error: .noValue, attempts: initial.attempts, recovery: trace)
    }
    guard result.error == .success, validation["valid"] as? Bool == true, let value = result.value else {
        return failed("Native scalar query failed or did not return the actual expected native value type.")
    }
    trace["resolved"] = true; trace["resolution_kind"] = "value"
    return ReadResult(value: value, error: .success, attempts: initial.attempts, recovery: trace)
}

func recoverNativeMetadataBatch(_ names: [String], initial: [String: ReadResult<CFTypeRef>],
                                query: () -> ReadResult<CFArray>,
                                decodeError: (AXValue) -> AXError? = { value in
                                    var error = AXError.success
                                    return AXValueGetValue(value, .axError, &error) ? error : nil
                                }) -> [String: ReadResult<CFTypeRef>] {
    guard !names.isEmpty else { return [:] }
    let batch = query()
    let items = batch.value as? [Any]
    let validSelection = Set(names).count == names.count && names.allSatisfy { initial[$0] != nil }
    var results: [String: ReadResult<CFTypeRef>] = [:]
    for (index, name) in names.enumerated() {
        guard let original = initial[name] else { continue }
        var trace: [String: Any] = ["method": "AXUIElementCopyMultipleAttributeValues", "query_attributes": names,
                                   "options": 0, "query_status": nativeReadStatus(batch), "has_array": batch.value != nil,
                                   "returned_slot_count": items?.count ?? NSNull(), "slot_index": index,
                                   "slot_attribute": name, "item_kind": "malformed", "item_status": NSNull(),
                                   "item_error_decoded": false, "cf_type_id": NSNull(), "resolved": false,
                                   "resolution_kind": "unresolved"]
        func unresolved(_ reason: String) -> ReadResult<CFTypeRef> {
            trace["reason"] = reason
            return ReadResult(value: original.value, error: original.error, attempts: original.attempts, recovery: trace)
        }
        guard validSelection else { results[name] = unresolved("Batch attribute selection was not unique or lacked matching original reads."); continue }
        guard batch.error == .success else { results[name] = unresolved("Native bulk attribute query failed; the original attribute error is retained."); continue }
        guard let items else { results[name] = unresolved("Native bulk query returned no usable array."); continue }
        guard items.count == names.count else { results[name] = unresolved("Native bulk result cardinality does not match the exact ordered query attributes."); continue }
        let item = items[index] as CFTypeRef
        let type = CFGetTypeID(item)
        trace["cf_type_id"] = Int(type)
        if type == CFNullGetTypeID() {
            trace["item_kind"] = "null"
            results[name] = unresolved("Native bulk slot was CFNull, not an attribute value.")
            continue
        }
        if type == AXValueGetTypeID(), AXValueGetType(item as! AXValue) == .axError {
            trace["item_kind"] = "ax_error"
            if let error = decodeError(item as! AXValue) {
                trace["item_error_decoded"] = true
                trace["item_status"] = ["code": error.rawValue, "name": errorName(error)]
                if error == .noValue {
                    // An exact successful options=0 bulk slot explicitly reports
                    // native absence. It is not an empty value or a failed read.
                    trace["resolved"] = true
                    trace["resolution_kind"] = "absence"
                    results[name] = ReadResult(value: nil, error: .noValue, attempts: original.attempts, recovery: trace)
                } else {
                    results[name] = unresolved("Native bulk slot contained an AX error envelope; the per-slot error and original query error are retained.")
                }
            } else {
                results[name] = unresolved("Native bulk AX error envelope could not be decoded.")
            }
            continue
        }
        trace["item_kind"] = "value"
        if nativeScalarExpectedValueKind(name) != nil {
            let validation = nativeScalarValueValidation(name, item)
            trace["value_validation"] = validation
            guard validation["valid"] as? Bool == true else {
                results[name] = unresolved("Native bulk value slot does not match the known scalar type contract.")
                continue
            }
        }
        trace["resolved"] = true
        trace["resolution_kind"] = "value"
        results[name] = ReadResult(value: item, error: .success, attempts: original.attempts, recovery: trace)
    }
    return results
}

func recoverNativeMetadataReads(_ names: [String], initial: [String: ReadResult<CFTypeRef>],
                                batchQuery: () -> ReadResult<CFArray>,
                                arrayQuery: (String, ReadResult<CFTypeRef>) -> ReadResult<CFTypeRef>,
                                scalarQuery: (String, ReadResult<CFTypeRef>) -> ReadResult<CFTypeRef>) -> [String: ReadResult<CFTypeRef>] {
    let bulkResults = recoverNativeMetadataBatch(names, initial: initial, query: batchQuery)
    var results: [String: ReadResult<CFTypeRef>] = [:]
    for name in names {
        guard let original = initial[name], let bulk = bulkResults[name] else { continue }
        var queries: [[String: Any]] = []
        if let trace = bulk.recovery { queries.append(trace) }
        var selected = bulk
        var selectedMethod: Any = NSNull()
        let bulkAbsence = bulk.error == .noValue && bulk.value == nil &&
            bulk.recovery?["resolved"] as? Bool == true && bulk.recovery?["resolution_kind"] as? String == "absence"
        if (bulk.error == .success && bulk.value != nil) || bulkAbsence {
            selectedMethod = "AXUIElementCopyMultipleAttributeValues"
        } else if nativeScalarExpectedValueKind(name) != nil {
            if nativeMetadataRecoveryEligible(original.error) {
                let scalar = scalarQuery(name, original)
                if let trace = scalar.recovery { queries.append(trace) }
                if (scalar.error == .success && scalar.value != nil) ||
                    (scalar.error == .noValue && scalar.value == nil && scalar.recovery?["resolution_kind"] as? String == "absence") {
                    selected = scalar
                    selectedMethod = "native_scalar_recovery"
                }
            }
        } else {
            let array = arrayQuery(name, original)
            if let trace = array.recovery { queries.append(trace) }
            if array.error == .success, array.value != nil {
                selected = array
                selectedMethod = "AXUIElementGetAttributeValueCount/AXUIElementCopyAttributeValues"
            }
        }
        let absence = selected.error == .noValue && selected.value == nil &&
            selected.recovery?["resolved"] as? Bool == true && selected.recovery?["resolution_kind"] as? String == "absence"
        let value = selected.error == .success && selected.value != nil
        let resolved = value || absence
        var composite: [String: Any] = ["method": "native_metadata_recovery", "initial_status": nativeReadStatus(original),
                                       "queries": queries, "resolved": resolved, "selected_method": selectedMethod,
                                       "resolution_kind": absence ? "absence" : value ? "value" : "unresolved"]
        if let expected = nativeScalarExpectedValueKind(name) {
            composite["documented_scalar"] = ["attribute": name, "expected_value_kind": expected,
                                              "array_query_skipped": true,
                                              "scalar_retry_eligible": nativeMetadataRecoveryEligible(original.error)]
        }
        results[name] = ReadResult(value: absence ? nil : value ? selected.value : original.value,
                                  error: absence ? .noValue : value ? .success : original.error,
                                  attempts: original.attempts, recovery: composite)
    }
    return results
}

func recoverNativeActionNames(_ initial: ReadResult<CFArray>, query: () -> ReadResult<CFArray>) -> ReadResult<CFArray> {
    guard initial.error == .failure else { return initial }
    let next = query()
    let items = next.value as? [Any]
    let names = next.value as? [String]
    let resolved = next.error == .success && names != nil
    var trace: [String: Any] = ["method": "native_action_names_recovery", "initial_status": nativeReadStatus(initial),
                              "initial_has_array": initial.value != nil,
                              "initial_returned_count": (initial.value as? [Any])?.count ?? NSNull(),
                              "query_status": nativeReadStatus(next), "has_array": next.value != nil,
                              "returned_count": items?.count ?? NSNull(), "names_valid": names != nil,
                              "strings_count": items?.filter { $0 is String }.count ?? NSNull(), "resolved": resolved,
                              "resolution_kind": resolved ? "value" : "unresolved"]
    if !resolved { trace["reason"] = "The bounded fresh action-name query did not return a successful native string array." }
    return ReadResult(value: resolved ? next.value : initial.value, error: resolved ? .success : initial.error,
                      attempts: initial.attempts, recovery: trace)
}

func nativeActionNamesForExport(_ result: ReadResult<CFArray>) -> [String]? {
    guard result.error == .success else { return nil }
    return result.value as? [String]
}

func nativeMetadataFailureSummary(_ records: [[String: Any]]) -> [String: Int] {
    let reads = records.filter { $0["stage"] as? String != "serialization" }
    let unsupported = reads.filter { (($0["status"] as? [String: Any])?["code"] as? NSNumber)?.int32Value == AXError.attributeUnsupported.rawValue }.count
    return ["attribute_unsupported": unsupported, "other_read_failures": reads.count - unsupported]
}

func nativeScalarRecoverySelfTest() throws -> Int {
    func check(_ condition: Bool, _ message: String) throws {
        if !condition { throw EngineError.message("Native scalar recovery fixture failed: \(message)") }
    }
    // Constructors allocate opaque references only. Every read/PID/process
    // result below is synthetic; these fixtures do not query any application.
    let rootPID: pid_t = 42001, ownerPID: pid_t = 42002
    let root = AXUIElementCreateApplication(rootPID), owner = AXUIElementCreateApplication(ownerPID)
    let swapped = AXUIElementCreateApplication(42003)
    let original = ReadResult<CFTypeRef>(value: nil, error: .failure, attempts: 1)
    let path: [[String: Any]] = [["attribute": "AXChildren", "value_path": [0]]]
    func refresh(selector: [[String: Any]] = path, value: CFTypeRef? = [owner] as CFArray,
                 readError: AXError = .success, process: @escaping (pid_t) -> Bool = { _ in true },
                 timeout: AXError = .success, missingPrefix: Bool = false, rootOverride: AXUIElement? = nil,
                 pidError: AXError = .success, pidOverride: pid_t? = nil) -> NativeScalarRefreshResult {
        refreshNativeScalarTarget(selectorPath: selector, rootPID: rootPID,
                                  expectedPID: selector.isEmpty ? rootPID : ownerPID, recordedAtPath: { prefix in
            if prefix.isEmpty { return (root, rootPID) }
            return missingPrefix ? nil : (owner, ownerPID)
        }, processMatches: process, createRoot: { rootOverride ?? root }, setTimeout: { _ in timeout },
        readAttribute: { _, _ in ReadResult(value: value, error: readError, attempts: 1) }, elementPID: { element in
            ReadResult(value: pidError == .success ? NSNumber(value: pidOverride ?? (CFEqual(element, root) ? rootPID : ownerPID)) : nil,
                       error: pidError, attempts: 1)
        })
    }
    var point = CGPoint(x: 1, y: 2), size = CGSize(width: 3, height: 4), rect = CGRect(x: 5, y: 6, width: 7, height: 8)
    let pointValue = AXValueCreate(.cgPoint, &point)!, sizeValue = AXValueCreate(.cgSize, &size)!, rectValue = AXValueCreate(.cgRect, &rect)!
    let typed: [(String, CFTypeRef)] = [("AXGrowArea", owner), ("AXTopLevelUIElement", owner),
                                      ("AXPosition", pointValue), ("AXSize", sizeValue), ("AXFrame", rectValue)]
    var fixtures = 0
    for (name, value) in typed {
        var arrays = 0, scalars = 0
        let bulk = recoverNativeMetadataReads([name], initial: [name: original], batchQuery: {
            ReadResult(value: [value] as CFArray, error: .success, attempts: 1)
        }, arrayQuery: { _, result in arrays += 1; return result }, scalarQuery: { _, result in scalars += 1; return result })[name]!
        try check(bulk.error == .success && bulk.recovery?["resolution_kind"] as? String == "value" && arrays == 0 && scalars == 0 &&
                  (bulk.recovery?["queries"] as? [[String: Any]])?.first?["value_validation"] as? [String: Any] != nil,
                  "each known scalar accepts only its actual native typed bulk value without array or fresh queries")
        fixtures += 1
        let fresh = recoverNativeMetadataReads([name], initial: [name: original], batchQuery: {
            ReadResult(value: [kCFNull!] as CFArray, error: .success, attempts: 1)
        }, arrayQuery: { _, result in arrays += 1; return result }, scalarQuery: { name, result in
            recoverNativeScalar(name, result, refresh: { refresh() }, query: { _ in scalars += 1; return ReadResult(value: value, error: .success, attempts: 1) })
        })[name]!
        try check(fresh.error == .success && fresh.recovery?["selected_method"] as? String == "native_scalar_recovery" &&
                  (fresh.recovery?["queries"] as? [[String: Any]])?.count == 2 && scalars == 1 && arrays == 0,
                  "each known scalar can recover one typed native value through an exact refreshed owner")
        fixtures += 1
    }
    var unsupportedError = AXError.attributeUnsupported
    let unsupportedEnvelope = AXValueCreate(.axError, &unsupportedError)!
    for (name, _) in typed {
        var arrays = 0, scalars = 0
        let unsupported = ReadResult<CFTypeRef>(value: nil, error: .attributeUnsupported, attempts: 1)
        let result = recoverNativeMetadataReads([name], initial: [name: unsupported], batchQuery: {
            ReadResult(value: [unsupportedEnvelope] as CFArray, error: .success, attempts: 1)
        }, arrayQuery: { _, result in arrays += 1; return result }, scalarQuery: { attribute, result in
            recoverNativeScalar(attribute, result, refresh: { refresh() }, query: { _ in
                scalars += 1; return ReadResult(value: nil, error: .attributeUnsupported, attempts: 1)
            })
        })[name]!
        try check(result.error == .attributeUnsupported && result.value == nil && arrays == 0 && scalars == 1 &&
                  (result.recovery?["queries"] as? [[String: Any]])?.count == 2 &&
                  (result.recovery?["documented_scalar"] as? [String: Any])?["scalar_retry_eligible"] as? Bool == true,
                  "known unsupported scalars get one exact fresh scalar read and preserve unsupported errors without array queries")
        fixtures += 1
    }
    for (name, _) in typed {
        let wrong = recoverNativeMetadataBatch([name], initial: [name: original], query: {
            ReadResult(value: [[] as CFArray] as CFArray, error: .success, attempts: 1)
        })[name]!
        try check(wrong.error == .failure && wrong.value == nil && wrong.recovery?["item_kind"] as? String == "value" &&
                  wrong.recovery?["resolution_kind"] as? String == "unresolved" &&
                  (wrong.recovery?["value_validation"] as? [String: Any])?["valid"] as? Bool == false,
                  "an actual but wrong native bulk type cannot resolve a known scalar")
        fixtures += 1
    }
    let cannotComplete = ReadResult<CFTypeRef>(value: kCFBooleanTrue!, error: .cannotComplete, attempts: 3)
    let absent = recoverNativeScalar("AXGrowArea", cannotComplete, refresh: { refresh() }, query: { _ in ReadResult(value: owner, error: .noValue, attempts: 1) })
    try check(absent.error == .noValue && absent.value == nil && absent.attempts == 3 &&
              absent.recovery?["resolution_kind"] as? String == "absence",
              "explicit fresh native noValue confirms absence and discards any untrusted returned value")
    fixtures += 1
    var envelopeError = AXError.success
    let errorEnvelope = AXValueCreate(.axError, &envelopeError)!
    let rejected: [ReadResult<CFTypeRef>] = [ReadResult(value: nil, error: .success, attempts: 1),
        ReadResult(value: kCFNull!, error: .success, attempts: 1), ReadResult(value: [] as CFArray, error: .success, attempts: 1),
        ReadResult(value: kCFBooleanFalse!, error: .success, attempts: 1), ReadResult(value: errorEnvelope, error: .success, attempts: 1),
        ReadResult(value: owner, error: .attributeUnsupported, attempts: 1), ReadResult(value: owner, error: .failure, attempts: 1),
        ReadResult(value: owner, error: .cannotComplete, attempts: 1)]
    for next in rejected {
        var calls = 0
        let result = recoverNativeScalar("AXGrowArea", original, refresh: { refresh() }, query: { _ in calls += 1; return next })
        try check(calls == 1 && result.error == .failure && result.value == nil &&
                  result.recovery?["resolution_kind"] as? String == "unresolved" &&
                  (result.recovery?["query_status"] as? [String: Any])?["code"] as? Int32 == next.error.rawValue,
                  "one fresh read preserves nil-success, null, error-envelope, wrong-type and native error evidence without masking failure")
        fixtures += 1
    }
    let wrongGeometry = recoverNativeScalar("AXPosition", original, refresh: { refresh() }, query: { _ in ReadResult(value: sizeValue, error: .success, attempts: 1) })
    try check(wrongGeometry.error == .failure && (wrongGeometry.recovery?["value_validation"] as? [String: Any])?["ax_value_type"] as? String == "cgSize",
              "geometry recovery requires the exact native AXValue subtype")
    fixtures += 1
    let identityChangedResults: [ReadResult<CFTypeRef>] = [ReadResult(value: owner, error: .success, attempts: 1), ReadResult(value: nil, error: .noValue, attempts: 1)]
    for next in identityChangedResults {
        let result = recoverNativeScalar("AXGrowArea", original, refresh: { refresh() }, query: { _ in next }, queryIdentityMatches: { false })
        try check(result.error == .failure && result.value == nil && result.recovery?["query_process_identity_matches"] as? Bool == false &&
                  result.recovery?["resolution_kind"] as? String == "unresolved",
                  "post-query process/launch identity changes cannot resolve either content or absence")
        fixtures += 1
    }
    var intermediateCalls = 0
    let failedRefreshes: [() -> NativeScalarRefreshResult] = [
        { refresh(process: { _ in false }) }, { refresh(rootOverride: swapped) }, { refresh(timeout: .failure) },
        { refresh(readError: .cannotComplete) }, { refresh(value: nil) }, { refresh(value: [swapped] as CFArray) },
        { refresh(value: [] as CFArray) }, { refresh(value: ["wrong-reference"] as CFArray) },
        { refresh(selector: [["attribute": "AXChildren", "value_path": [true]]]) },
        { refresh(selector: [["attribute": "AXChildren", "value_path": ["not-an-array-index"]]]) },
        { refresh(missingPrefix: true) }, { refresh(pidError: .invalidUIElement) }, { refresh(pidOverride: ownerPID + 1) },
        { refresh(process: { _ in intermediateCalls += 1; return intermediateCalls != 3 }) }]
    for makeRefresh in failedRefreshes {
        var calls = 0
        let result = recoverNativeScalar("AXGrowArea", original, refresh: makeRefresh, query: { _ in calls += 1; return ReadResult(value: owner, error: .success, attempts: 1) })
        try check(calls == 0 && result.error == .failure && result.recovery?["query_status"] is NSNull &&
                  result.recovery?["query_process_identity_matches"] is NSNull &&
                  (result.recovery?["refresh"] as? [String: Any])?["resolved"] as? Bool == false,
                  "failed exact path/reference/PID/launch validation prevents every scalar query")
        fixtures += 1
    }
    let nestedPath: [[String: Any]] = [["attribute": "AXSections", "value_path": ["content", 0]]]
    let nested = refresh(selector: nestedPath, value: ["content": [owner]] as CFDictionary)
    try check(nested.evidence["resolved"] as? Bool == true &&
              ((nested.evidence["steps"] as? [[String: Any]])?.first?["path_steps"] as? [[String: Any]])?.count == 2,
              "fresh native paths can traverse exact string dictionary keys and array indexes")
    fixtures += 1
    let rootOwner = refresh(selector: [])
    try check(rootOwner.evidence["resolved"] as? Bool == true && rootOwner.evidence["pid"] as? NSNumber == NSNumber(value: rootPID),
              "an empty selector path refreshes only the exact original application root")
    fixtures += 1
    var arrayCalls = 0, scalarCalls = 0
    let custom = "AXCustomSelectionRanges"
    let generic = recoverNativeMetadataReads([custom], initial: [custom: original], batchQuery: { ReadResult(value: [kCFNull!] as CFArray, error: .success, attempts: 1) },
        arrayQuery: { _, result in arrayCalls += 1; return recoverNativeArray(result, count: { ReadResult(value: NSNumber(value: 0), error: .success, attempts: 1) }, values: { _, _ in throwawayArrayPage() }) },
        scalarQuery: { _, result in scalarCalls += 1; return result })[custom]!
    try check(generic.error == .success && (generic.value as? [Any])?.isEmpty == true && arrayCalls == 1 && scalarCalls == 0 &&
              generic.recovery?["documented_scalar"] == nil,
              "unknown custom array attributes retain native count/page recovery")
    fixtures += 1
    let summary = nativeMetadataFailureSummary([["stage": "attribute_read", "status": nativeReadStatus(ReadResult<CFTypeRef>(value: nil, error: .attributeUnsupported, attempts: 1))],
        ["stage": "attribute_read", "status": nativeReadStatus(original)], ["stage": "serialization", "status": ["code": 0]]])
    try check(summary == ["attribute_unsupported": 1, "other_read_failures": 1], "failure summary partitions only native read failures and preserves unsupported counts")
    fixtures += 1
    return fixtures
}

func nativeScalarUnsupportedRetrySelfTest() throws -> Int {
    func check(_ condition: Bool, _ message: String) throws {
        if !condition { throw EngineError.message("Native unsupported scalar retry fixture failed: \(message)") }
    }
    // Opaque reference constructors and native AXValue conversions only;
    // every attribute/PID/launch response is a synthetic callback.
    let rootPID: pid_t = 44001, ownerPID: pid_t = 44002
    let root = AXUIElementCreateApplication(rootPID), owner = AXUIElementCreateApplication(ownerPID)
    let other = AXUIElementCreateApplication(44003)
    let path: [[String: Any]] = [["attribute": "AXChildren", "value_path": [0]]]
    var unsupportedError = AXError.attributeUnsupported, absenceError = AXError.noValue
    let unsupportedEnvelope = AXValueCreate(.axError, &unsupportedError)!, absenceEnvelope = AXValueCreate(.axError, &absenceError)!
    let original = ReadResult<CFTypeRef>(value: nil, error: .attributeUnsupported, attempts: 1)
    func result(_ name: String, next: ReadResult<CFTypeRef>, initial: ReadResult<CFTypeRef> = original,
                bulk: CFTypeRef = unsupportedEnvelope, wrongOwner: Bool = false,
                preIdentity: Bool = true, postIdentity: Bool = true) -> (read: ReadResult<CFTypeRef>, scalarCalls: Int, arrayCalls: Int) {
        var scalarCalls = 0, arrayCalls = 0
        let read = recoverNativeMetadataReads([name], initial: [name: initial], batchQuery: {
            ReadResult(value: [bulk] as CFArray, error: .success, attempts: 1)
        }, arrayQuery: { _, value in arrayCalls += 1; return value }, scalarQuery: { attribute, initial in
            recoverNativeScalar(attribute, initial, refresh: {
                refreshNativeScalarTarget(selectorPath: path, rootPID: rootPID, expectedPID: ownerPID,
                    recordedAtPath: { $0.isEmpty ? (root, rootPID) : (owner, ownerPID) },
                    processMatches: { _ in preIdentity }, createRoot: { root }, setTimeout: { _ in .success },
                    readAttribute: { _, _ in ReadResult(value: [wrongOwner ? other : owner] as CFArray, error: .success, attempts: 1) },
                    elementPID: { _ in ReadResult(value: NSNumber(value: ownerPID), error: .success, attempts: 1) })
            }, query: { _ in scalarCalls += 1; return next }, queryIdentityMatches: { postIdentity })
        })[name]!
        return (read, scalarCalls, arrayCalls)
    }
    var point = CGPoint(x: 9, y: 10), size = CGSize(width: 11, height: 12), rect = CGRect(x: 13, y: 14, width: 15, height: 16)
    let pointValue = AXValueCreate(.cgPoint, &point)!, sizeValue = AXValueCreate(.cgSize, &size)!, rectValue = AXValueCreate(.cgRect, &rect)!
    let typed: [(String, CFTypeRef)] = [("AXGrowArea", owner), ("AXTopLevelUIElement", owner),
                                      ("AXPosition", pointValue), ("AXSize", sizeValue), ("AXFrame", rectValue)]
    var fixtures = 0
    for (name, value) in typed {
        let recovered = result(name, next: ReadResult(value: value, error: .success, attempts: 1))
        let queries = recovered.read.recovery?["queries"] as? [[String: Any]]
        try check(recovered.read.error == .success && recovered.scalarCalls == 1 && recovered.arrayCalls == 0 &&
                  recovered.read.attempts == 1 && queries?.count == 2 &&
                  (queries?.last?["initial_status"] as? [String: Any])?["code"] as? Int32 == AXError.attributeUnsupported.rawValue &&
                  (recovered.read.recovery?["initial_status"] as? [String: Any])?["code"] as? Int32 == AXError.attributeUnsupported.rawValue &&
                  (recovered.read.recovery?["documented_scalar"] as? [String: Any])?["scalar_retry_eligible"] as? Bool == true,
                  "each initially unsupported scalar may recover its real typed native value in one exact fresh query")
        fixtures += 1
    }
    let absence = result("AXTopLevelUIElement", next: ReadResult(value: owner, error: .noValue, attempts: 1),
                         initial: ReadResult(value: kCFBooleanTrue!, error: .attributeUnsupported, attempts: 1))
    try check(absence.read.error == .noValue && absence.read.value == nil && absence.scalarCalls == 1 && absence.arrayCalls == 0 &&
              absence.read.recovery?["resolution_kind"] as? String == "absence",
              "explicit fresh native noValue resolves unsupported as absence and drops untrusted values")
    fixtures += 1
    let stillUnsupported = result("AXGrowArea", next: ReadResult(value: owner, error: .attributeUnsupported, attempts: 1))
    try check(stillUnsupported.read.error == .attributeUnsupported && stillUnsupported.read.value == nil &&
              stillUnsupported.scalarCalls == 1 && stillUnsupported.arrayCalls == 0 &&
              stillUnsupported.read.recovery?["resolution_kind"] as? String == "unresolved",
              "a fresh unsupported result preserves the original unsupported error even with a returned native reference")
    fixtures += 1
    let wrongValues: [(String, CFTypeRef)] = [("AXPosition", sizeValue), ("AXGrowArea", [] as CFArray)]
    for (name, wrong) in wrongValues {
        let rejected = result(name, next: ReadResult(value: wrong, error: .success, attempts: 1))
        try check(rejected.read.error == .attributeUnsupported && rejected.read.value == nil && rejected.scalarCalls == 1 &&
                  rejected.arrayCalls == 0 && rejected.read.recovery?["resolution_kind"] as? String == "unresolved",
                  "wrong geometry subtypes or arrays cannot replace an unsupported scalar error")
        fixtures += 1
    }
    let swapped = result("AXGrowArea", next: ReadResult(value: owner, error: .success, attempts: 1), wrongOwner: true)
    try check(swapped.read.error == .attributeUnsupported && swapped.scalarCalls == 0 && swapped.arrayCalls == 0 &&
              (swapped.read.recovery?["queries"] as? [[String: Any]])?.last?["query_status"] is NSNull,
              "a swapped native owner refuses unsupported retry before any scalar query")
    fixtures += 1
    let changedBefore = result("AXSize", next: ReadResult(value: sizeValue, error: .success, attempts: 1), preIdentity: false)
    try check(changedBefore.read.error == .attributeUnsupported && changedBefore.scalarCalls == 0 && changedBefore.arrayCalls == 0,
              "changed process launch identity prevents unsupported retry before any query")
    fixtures += 1
    let changedAfter = result("AXFrame", next: ReadResult(value: rectValue, error: .success, attempts: 1), postIdentity: false)
    try check(changedAfter.read.error == .attributeUnsupported && changedAfter.scalarCalls == 1 && changedAfter.arrayCalls == 0 &&
              (changedAfter.read.recovery?["queries"] as? [[String: Any]])?.last?["query_process_identity_matches"] as? Bool == false,
              "a post-query identity change preserves unsupported despite a typed native reply")
    fixtures += 1
    var queries = 0
    let invalid = ReadResult<CFTypeRef>(value: nil, error: .invalidUIElement, attempts: 1)
    let untouched = recoverNativeScalar("AXGrowArea", invalid, refresh: { queries += 1; return NativeScalarRefreshResult(element: nil, evidence: [:]) },
                                       query: { _ in queries += 1; return ReadResult(value: owner, error: .success, attempts: 1) })
    try check(untouched.error == .invalidUIElement && untouched.recovery == nil && queries == 0,
              "unsupported retry does not broaden recovery to invalid references")
    fixtures += 1
    let bulkTyped = result("AXSize", next: ReadResult(value: nil, error: .failure, attempts: 1), bulk: sizeValue)
    try check(bulkTyped.read.error == .success && bulkTyped.scalarCalls == 0 && bulkTyped.arrayCalls == 0 &&
              (bulkTyped.read.recovery?["queries"] as? [[String: Any]])?.count == 1,
              "a typed bulk value terminates unsupported recovery before a fresh query")
    fixtures += 1
    let bulkAbsence = result("AXGrowArea", next: ReadResult(value: nil, error: .failure, attempts: 1), bulk: absenceEnvelope)
    try check(bulkAbsence.read.error == .noValue && bulkAbsence.read.value == nil && bulkAbsence.scalarCalls == 0 &&
              bulkAbsence.arrayCalls == 0 && (bulkAbsence.read.recovery?["queries"] as? [[String: Any]])?.count == 1,
              "an exact decoded bulk noValue terminates unsupported recovery as absence")
    fixtures += 1
    return fixtures
}

func nativeMenuReferenceRetrySelfTest() throws -> Int {
    var fixtures = 0
    func require(_ condition: Bool, _ message: String) throws {
        fixtures += 1
        if !condition { throw EngineError.message("Native menu-reference retry self-test failed: \(message)") }
    }
    let rootPID: pid_t = 46001, prefixPID: pid_t = 46002, ownerPID: pid_t = 46003
    let root = AXUIElementCreateApplication(rootPID), prefix = AXUIElementCreateApplication(prefixPID)
    let owner = AXUIElementCreateApplication(ownerPID), changed = AXUIElementCreateApplication(46004)
    let selector: [[String: Any]] = [["attribute": "AXChildren", "value_path": [0]], ["attribute": "AXChildren", "value_path": [0]]]
    let roleStatus = ReadResult<CFTypeRef>(value: "AXMenuItem" as CFString, error: .success, attempts: 1).status
    let original = ReadResult<CFTypeRef>(value: nil, error: .attributeUnsupported, attempts: 1)
    func fresh(selected: CFTypeRef = [changed] as CFArray, pidError: AXError = .success,
               pid: pid_t = prefixPID, process: Bool = true, timeout: AXError = .success) -> NativeScalarRefreshResult {
        refreshNativeScalarTarget(selectorPath: selector, rootPID: rootPID, expectedPID: ownerPID,
            recordedAtPath: { path in path.isEmpty ? (root, rootPID) : path.count == 1 ? (prefix, prefixPID) : (owner, ownerPID) },
            processMatches: { _ in process }, createRoot: { root }, setTimeout: { _ in timeout },
            readAttribute: { _, _ in ReadResult(value: selected, error: .success, attempts: 1) },
            elementPID: { _ in ReadResult(value: pidError == .success ? NSNumber(value: pid) : nil, error: pidError, attempts: 1) })
    }
    func retained(target: AXUIElement = owner, role: String = "AXMenuItem", roleRead: [String: Any] = roleStatus,
                  rootError: AXError = .success, ownerError: AXError = .success,
                  rootNativePID: pid_t = rootPID, ownerNativePID: pid_t = ownerPID,
                  process: (pid_t) -> Bool = { _ in true }) -> NativeScalarRefreshResult {
        validateRetainedNativeScalarTarget(nodeID: 2, rootID: 0, rootPID: rootPID, expectedPID: ownerPID,
            ownerRole: role, ownerRoleStatus: roleRead, retainedOwner: target,
            recordedAtID: { id in id == 0 ? (root, rootPID) : id == 2 ? (owner, ownerPID) : nil },
            processMatches: process, elementPID: { element in
                let isRoot = CFEqual(element, root), error = isRoot ? rootError : ownerError
                return ReadResult(value: error == .success ? NSNumber(value: isRoot ? rootNativePID : ownerNativePID) : nil, error: error, attempts: 1)
            })
    }
    var queries = 0, retainedChecks = 0
    func run(_ next: ReadResult<CFTypeRef>, attribute: String = "AXTopLevelUIElement",
             refresh: () -> NativeScalarRefreshResult = { fresh() },
             before: @escaping () -> NativeScalarRefreshResult = { retained() },
             after: @escaping () -> NativeScalarRefreshResult = { retained() }, identity: Bool = true) -> ReadResult<CFTypeRef> {
        queries = 0; retainedChecks = 0
        return recoverNativeScalar(attribute, original, refresh: refresh, query: { element in
            queries += 1
            precondition(CFEqual(element, owner), "A replacement menu prefix must never be the query target")
            return next
        }, queryIdentityMatches: { identity }, retainedTarget: { retainedChecks += 1; return before() },
        retainedQueryValidation: { element in
            precondition(CFEqual(element, owner), "Post-query continuity must check the original owner")
            return after()
        })
    }
    let mismatch = fresh()
    try require(nativeScalarRetainedReferenceEligible(mismatch.evidence), "An isolated intermediate-prefix CFEqual mismatch is eligible")
    var rootMismatch = mismatch.evidence
    rootMismatch["root_same_element"] = false
    try require(!nativeScalarRetainedReferenceEligible(rootMismatch), "A changed native root can never enter retained mode")
    let exactRefresh = refreshNativeScalarTarget(selectorPath: selector, rootPID: rootPID, expectedPID: ownerPID,
        recordedAtPath: { path in path.isEmpty ? (root, rootPID) : path.count == 1 ? (prefix, prefixPID) : (owner, ownerPID) },
        processMatches: { _ in true }, createRoot: { root }, setTimeout: { _ in .success },
        readAttribute: { current, _ in ReadResult(value: [CFEqual(current, root) ? prefix : owner] as CFArray, error: .success, attempts: 1) },
        elementPID: { current in ReadResult(value: NSNumber(value: CFEqual(current, prefix) ? prefixPID : ownerPID), error: .success, attempts: 1) })
    let exact = run(ReadResult(value: root, error: .success, attempts: 1), refresh: { exactRefresh })
    try require(exact.error == .success && queries == 1 && retainedChecks == 0 && exact.recovery?["query_target"] as? String == "fresh_exact_reference" &&
                exact.recovery?["retained_reference"] is NSNull && exact.recovery?["query_retained_reference_validation"] is NSNull,
                "A fresh exact native reference remains the normal one-query path")
    let typed = run(ReadResult(value: root, error: .success, attempts: 1))
    try require(typed.error == .success && queries == 1 && retainedChecks == 1 &&
                typed.recovery?["query_target"] as? String == "retained_original_reference" &&
                (typed.recovery?["refresh"] as? [String: Any])?["resolved"] as? Bool == false,
                "One typed-value query uses the original owner and preserves failed fresh evidence")
    let absence = run(ReadResult(value: changed, error: .noValue, attempts: 1))
    try require(absence.error == .noValue && absence.value == nil && queries == 1 && absence.recovery?["resolution_kind"] as? String == "absence",
                "Native noValue is absence and drops untrusted returned content")
    for next in [ReadResult<CFTypeRef>(value: owner, error: .attributeUnsupported, attempts: 1),
                 ReadResult<CFTypeRef>(value: nil, error: .invalidUIElement, attempts: 1),
                 ReadResult<CFTypeRef>(value: nil, error: .success, attempts: 1),
                 ReadResult<CFTypeRef>(value: [] as CFArray, error: .success, attempts: 1)] {
        let result = run(next)
        try require(result.error == .attributeUnsupported && queries == 1 && result.recovery?["resolved"] as? Bool == false,
                    "Native scalar errors, nil-success and wrong types retain the original failure")
    }
    let badRefreshes = [fresh(selected: [] as CFArray), fresh(selected: [kCFBooleanTrue!] as CFArray),
                        fresh(pidError: .invalidUIElement), fresh(pid: prefixPID + 1), fresh(process: false), fresh(timeout: .failure)]
    for invalid in badRefreshes {
        let result = run(ReadResult(value: root, error: .success, attempts: 1), refresh: { invalid })
        try require(result.error == .attributeUnsupported && queries == 0 && retainedChecks == 0,
                    "A native path/type/PID/process/timeout failure must never select retained mode")
    }
    var failedRead = mismatch.evidence
    var failedSteps = failedRead["steps"] as! [[String: Any]]
    failedSteps[0]["query_status"] = ["code": AXError.failure.rawValue, "name": "failure", "attempts": 1]
    failedRead["steps"] = failedSteps
    try require(!nativeScalarRetainedReferenceEligible(failedRead), "A failed native prefix read is not an isolated reference mismatch")
    let badBefore = [retained(target: changed), retained(rootError: .invalidUIElement), retained(ownerError: .invalidUIElement),
                     retained(rootNativePID: rootPID + 1), retained(ownerNativePID: ownerPID + 1), retained(process: { _ in false })]
    for invalid in badBefore {
        let result = run(ReadResult(value: root, error: .success, attempts: 1), before: { invalid })
        try require(result.error == .attributeUnsupported && queries == 0 && retainedChecks == 1 &&
                    result.recovery?["query_target"] is NSNull,
                    "Unconfirmed registry/native PID/launch identity withholds the scalar query")
    }
    for invalid in [retained(ownerError: .invalidUIElement), retained(ownerNativePID: ownerPID + 1), retained(process: { _ in false })] {
        let result = run(ReadResult(value: root, error: .success, attempts: 1), after: { invalid })
        try require(result.error == .attributeUnsupported && queries == 1 && result.recovery?["query_target"] as? String == "retained_original_reference",
                    "Post-query native PID/launch failure preserves query evidence and original failure")
    }
    let changedIdentity = run(ReadResult(value: root, error: .success, attempts: 1), identity: false)
    try require(changedIdentity.error == .attributeUnsupported && queries == 1,
                "Existing post-query launch continuity remains mandatory in retained mode")
    try require(retained(role: "AXButton").evidence["resolved"] as? Bool == false,
                "An arbitrary non-menu role cannot validate for retained mode")
    try require(retained(roleRead: ["code": AXError.failure.rawValue, "name": "failure", "attempts": 1]).evidence["resolved"] as? Bool == false,
                "A failed captured native role read cannot authorize retained mode")
    let otherAttribute = run(ReadResult(value: root, error: .success, attempts: 1), attribute: "AXGrowArea")
    try require(otherAttribute.error == .attributeUnsupported && queries == 0 && retainedChecks == 0,
                "Retained-reference routing is limited to AXTopLevelUIElement")
    var launchChecks = 0
    let duringValidation = retained(process: { _ in launchChecks += 1; return launchChecks < 3 })
    try require(duringValidation.evidence["resolved"] as? Bool == false && duringValidation.evidence["owner_pid_status"] is [String: Any],
                "Launch continuity is checked again after native PID validation")
    return fixtures
}

func nativeMetadataBatchRecoverySelfTest() throws -> Int {
    func check(_ condition: Bool, _ message: String) throws {
        if !condition { throw EngineError.message("Native bulk metadata fixture failed: \(message)") }
    }
    func initial(_ names: [String], error: AXError = .failure) -> [String: ReadResult<CFTypeRef>] {
        Dictionary(uniqueKeysWithValues: names.map { ($0, ReadResult(value: nil, error: error, attempts: error == .cannotComplete ? 3 : 1)) })
    }
    func envelope(_ error: AXError) -> AXValue {
        var error = error
        return AXValueCreate(.axError, &error)!
    }
    var fixtures = 0
    let names = ["AXEnabled", "AXValue", "AXSelectedTextRanges", "AXDescription", "AXHelp", "AXPosition"]
    var point = CGPoint(x: 2, y: 3)
    let nativePoint = AXValueCreate(.cgPoint, &point)!
    let mixed: [Any] = [kCFBooleanFalse!, NSNumber(value: 0), [] as CFArray, kCFNull!, envelope(.attributeUnsupported), nativePoint]
    var queryCalls = 0
    let recovered = recoverNativeMetadataBatch(names, initial: initial(names), query: {
        queryCalls += 1; return ReadResult(value: mixed as CFArray, error: .success, attempts: 1)
    })
    try check(queryCalls == 1 && recovered["AXEnabled"]?.error == .success &&
              (recovered["AXEnabled"]?.value as? NSNumber)?.boolValue == false &&
              recovered["AXValue"]?.error == .success && (recovered["AXValue"]?.value as? NSNumber)?.intValue == 0 &&
              recovered["AXSelectedTextRanges"]?.error == .success && (recovered["AXSelectedTextRanges"]?.value as? [Any])?.isEmpty == true &&
              recovered["AXDescription"]?.error == .failure && recovered["AXDescription"]?.recovery?["item_kind"] as? String == "null" &&
              recovered["AXHelp"]?.error == .failure && recovered["AXHelp"]?.recovery?["item_error_decoded"] as? Bool == true &&
              (recovered["AXHelp"]?.recovery?["item_status"] as? [String: Any])?["code"] as? Int32 == AXError.attributeUnsupported.rawValue &&
              recovered["AXPosition"]?.error == .success, "mixed native values, null, and error envelopes remain distinct")
    fixtures += 1
    let one = ["AXTitle"]
    let outerFailure = recoverNativeMetadataBatch(one, initial: initial(one), query: {
        ReadResult(value: ["Native title"] as CFArray, error: .cannotComplete, attempts: 1)
    })
    try check(outerFailure["AXTitle"]?.error == .failure && outerFailure["AXTitle"]?.value == nil &&
              (outerFailure["AXTitle"]?.recovery?["query_status"] as? [String: Any])?["code"] as? Int32 == AXError.cannotComplete.rawValue,
              "an outer query error never turns a returned slot into success")
    fixtures += 1
    let nilArray = recoverNativeMetadataBatch(one, initial: initial(one), query: { ReadResult(value: nil, error: .success, attempts: 1) })
    try check(nilArray["AXTitle"]?.error == .failure && nilArray["AXTitle"]?.recovery?["has_array"] as? Bool == false &&
              nilArray["AXTitle"]?.recovery?["returned_slot_count"] is NSNull, "success with nil is unresolved")
    fixtures += 1
    let two = ["AXTitle", "AXDescription"]
    for payload: [Any] in [["only-one"], ["one", "two", "unexpected-third"]] {
        let cardinality = recoverNativeMetadataBatch(two, initial: initial(two), query: { ReadResult(value: payload as CFArray, error: .success, attempts: 1) })
        try check(cardinality.values.allSatisfy { $0.error == .failure && $0.value == nil && $0.recovery?["resolved"] as? Bool == false },
                  "a cardinality mismatch invalidates every slot mapping")
        fixtures += 1
    }
    let ordered = recoverNativeMetadataBatch(two, initial: initial(two), query: { ReadResult(value: ["first", "second"] as CFArray, error: .success, attempts: 1) })
    try check(ordered["AXTitle"]?.value as? String == "first" && ordered["AXDescription"]?.value as? String == "second" &&
              ordered["AXTitle"]?.recovery?["query_attributes"] as? [String] == two, "native slots preserve exact query order")
    fixtures += 1
    let null = recoverNativeMetadataBatch(one, initial: initial(one), query: { ReadResult(value: [kCFNull!] as CFArray, error: .success, attempts: 1) })
    try check(null["AXTitle"]?.error == .failure && null["AXTitle"]?.recovery?["item_kind"] as? String == "null" &&
              null["AXTitle"]?.recovery?["cf_type_id"] as? Int == Int(CFNullGetTypeID()), "CFNull retains its native runtime type and is not an empty value")
    fixtures += 1
    for error: AXError in [.noValue, .illegalArgument, .failure, .cannotComplete, .success] {
        let item = recoverNativeMetadataBatch(one, initial: initial(one), query: { ReadResult(value: [envelope(error)] as CFArray, error: .success, attempts: 1) })
        try check(item["AXTitle"]?.error == (error == .noValue ? .noValue : .failure) && item["AXTitle"]?.value == nil &&
                  item["AXTitle"]?.recovery?["item_error_decoded"] as? Bool == true &&
                  (item["AXTitle"]?.recovery?["item_status"] as? [String: Any])?["code"] as? Int32 == error.rawValue &&
                  item["AXTitle"]?.recovery?["resolution_kind"] as? String == (error == .noValue ? "absence" : "unresolved"),
                  "decoded noValue confirms absence; other error envelopes retain the original failure without inventing a value")
        fixtures += 1
    }
    let unreadable = recoverNativeMetadataBatch(one, initial: initial(one), query: { ReadResult(value: [envelope(.failure)] as CFArray, error: .success, attempts: 1) }, decodeError: { _ in nil })
    try check(unreadable["AXTitle"]?.error == .failure && unreadable["AXTitle"]?.recovery?["item_error_decoded"] as? Bool == false &&
              unreadable["AXTitle"]?.recovery?["item_status"] is NSNull, "undecodable error envelopes stay unresolved")
    fixtures += 1
    queryCalls = 0
    let absent = recoverNativeMetadataBatch([], initial: [:], query: { queryCalls += 1; return ReadResult(value: nil, error: .failure, attempts: 1) })
    try check(absent.isEmpty && queryCalls == 0, "no failed candidates means no bulk query")
    fixtures += 1
    return fixtures
}

func nativeAbsenceRecoverySelfTest() throws -> Int {
    func check(_ condition: Bool, _ message: String) throws {
        if !condition { throw EngineError.message("Native absence recovery fixture failed: \(message)") }
    }
    func envelope(_ error: AXError) -> AXValue {
        var error = error
        return AXValueCreate(.axError, &error)!
    }
    let name = "AXHelp"
    let initial = ReadResult<CFTypeRef>(value: nil, error: .failure, attempts: 1)
    let noValue = envelope(.noValue)
    var fixtures = 0
    let bulk = recoverNativeMetadataBatch([name], initial: [name: initial], query: {
        ReadResult(value: [noValue] as CFArray, error: .success, attempts: 1)
    })[name]!
    try check(bulk.error == .noValue && bulk.value == nil && bulk.attempts == 1 &&
              bulk.recovery?["resolved"] as? Bool == true && bulk.recovery?["resolution_kind"] as? String == "absence" &&
              bulk.recovery?["item_kind"] as? String == "ax_error" && bulk.recovery?["item_error_decoded"] as? Bool == true &&
              (bulk.recovery?["item_status"] as? [String: Any])?["code"] as? Int32 == AXError.noValue.rawValue,
              "an exact native noValue slot confirms absence with its real envelope evidence")
    fixtures += 1
    var arrayCalls = 0
    func composite(_ original: ReadResult<CFTypeRef>, payload: CFArray? = [noValue] as CFArray,
                   error: AXError = .success) -> ReadResult<CFTypeRef> {
        recoverNativeMetadataReads([name], initial: [name: original], batchQuery: {
            ReadResult(value: payload, error: error, attempts: 1)
        }, arrayQuery: { _, result in
            arrayCalls += 1
            return recoverNativeArray(result, count: { ReadResult(value: nil, error: .illegalArgument, attempts: 1) },
                                      values: { _, _ in throwawayArrayPage() })
        }, scalarQuery: { _, original in original })[name]!
    }
    let cannotComplete = ReadResult<CFTypeRef>(value: nil, error: .cannotComplete, attempts: 3)
    let terminal = composite(cannotComplete)
    try check(terminal.error == .noValue && terminal.value == nil && terminal.attempts == 3 && arrayCalls == 0 &&
              terminal.recovery?["resolution_kind"] as? String == "absence" &&
              terminal.recovery?["selected_method"] as? String == "AXUIElementCopyMultipleAttributeValues" &&
              (terminal.recovery?["queries"] as? [[String: Any]])?.count == 1 &&
              (terminal.recovery?["initial_status"] as? [String: Any])?["code"] as? Int32 == AXError.cannotComplete.rawValue,
              "confirmed absence is terminal and retains the original failed read and attempts")
    fixtures += 1
    let untrusted = ReadResult<CFTypeRef>(value: kCFBooleanTrue!, error: .failure, attempts: 1)
    let discarded = composite(untrusted)
    try check(discarded.error == .noValue && discarded.value == nil && arrayCalls == 0,
              "confirmed absence drops any value accompanying the original failed read")
    fixtures += 1
    let empty = composite(initial, payload: [[] as CFArray] as CFArray)
    try check(empty.error == .success && (empty.value as? [Any])?.isEmpty == true &&
              empty.recovery?["resolution_kind"] as? String == "value" && arrayCalls == 0,
              "a genuine empty array remains a native value rather than absence")
    fixtures += 1
    for (payload, error): (CFArray?, AXError) in [([] as CFArray, .success),
                                                ([noValue, noValue] as CFArray, .success),
                                                ([noValue] as CFArray, .failure), (nil, .success)] {
        let result = composite(initial, payload: payload, error: error)
        try check(result.error == .failure && result.value == nil && result.recovery?["resolved"] as? Bool == false &&
                  result.recovery?["resolution_kind"] as? String == "unresolved",
                  "outer failure, nil, or invalid cardinality cannot confirm a noValue slot")
        fixtures += 1
    }
    let null = composite(initial, payload: [kCFNull!] as CFArray)
    try check(null.error == .failure && null.value == nil && null.recovery?["resolution_kind"] as? String == "unresolved",
              "CFNull is not native noValue evidence")
    fixtures += 1
    for error: AXError in [.success, .attributeUnsupported] {
        let result = recoverNativeMetadataBatch([name], initial: [name: initial], query: {
            ReadResult(value: [envelope(error)] as CFArray, error: .success, attempts: 1)
        })[name]!
        try check(result.error == .failure && result.value == nil && result.recovery?["resolution_kind"] as? String == "unresolved",
                  "success or unsupported error envelopes do not become absence or content")
        fixtures += 1
    }
    let undecodable = recoverNativeMetadataBatch([name], initial: [name: initial], query: {
        ReadResult(value: [noValue] as CFArray, error: .success, attempts: 1)
    }, decodeError: { _ in nil })[name]!
    try check(undecodable.error == .failure && undecodable.value == nil &&
              undecodable.recovery?["resolution_kind"] as? String == "unresolved" &&
              undecodable.recovery?["item_error_decoded"] as? Bool == false,
              "an undecodable native error envelope cannot confirm absence")
    fixtures += 1
    let names = ["AXHelp", "AXSelectedTextRanges"]
    let mixed = recoverNativeMetadataBatch(names, initial: [names[0]: initial, names[1]: initial], query: {
        ReadResult(value: [noValue, [] as CFArray] as CFArray, error: .success, attempts: 1)
    })
    try check(mixed[names[0]]?.error == .noValue && mixed[names[0]]?.value == nil &&
              mixed[names[0]]?.recovery?["slot_index"] as? Int == 0 &&
              mixed[names[1]]?.error == .success && (mixed[names[1]]?.value as? [Any])?.isEmpty == true &&
              mixed[names[1]]?.recovery?["resolution_kind"] as? String == "value" &&
              mixed[names[1]]?.recovery?["slot_index"] as? Int == 1,
              "exact mixed slots preserve independent absence and real empty-array outcomes")
    fixtures += 1
    let pagedEmpty = recoverNativeArray(initial, count: { ReadResult(value: NSNumber(value: 0), error: .success, attempts: 1) },
                                       values: { _, _ in throwawayArrayPage() })
    try check(pagedEmpty.error == .success && pagedEmpty.recovery?["resolution_kind"] as? String == "value",
              "native count-confirmed empty arrays resolve as values")
    fixtures += 1
    let actions = recoverNativeActionNames(ReadResult(value: nil, error: .failure, attempts: 1), query: {
        ReadResult(value: [] as CFArray, error: .success, attempts: 1)
    })
    try check(actions.error == .success && actions.recovery?["resolution_kind"] as? String == "value",
              "native empty action-name arrays resolve as values")
    fixtures += 1
    let unsupported = composite(ReadResult(value: nil, error: .attributeUnsupported, attempts: 1))
    try check(unsupported.error == .noValue && unsupported.value == nil &&
              unsupported.recovery?["resolution_kind"] as? String == "absence" &&
              (unsupported.recovery?["queries"] as? [[String: Any]])?.count == 1 && arrayCalls == 5,
              "an advertised unsupported original read may be resolved by exact noValue evidence without another array query")
    fixtures += 1
    return fixtures
}

func nativeMetadataCompositeRecoverySelfTest() throws -> Int {
    let name = "AXSelectedTextRanges"
    let original = ReadResult<CFTypeRef>(value: nil, error: .cannotComplete, attempts: 3)
    var arrayCalls = 0
    let bulk = recoverNativeMetadataReads([name], initial: [name: original], batchQuery: {
        ReadResult(value: [kCFBooleanFalse!] as CFArray, error: .success, attempts: 1)
    }, arrayQuery: { _, result in arrayCalls += 1; return result }, scalarQuery: { _, original in original })
    guard arrayCalls == 0, bulk[name]?.error == .success, bulk[name]?.attempts == 3,
          bulk[name]?.recovery?["method"] as? String == "native_metadata_recovery",
          bulk[name]?.recovery?["selected_method"] as? String == "AXUIElementCopyMultipleAttributeValues",
          (bulk[name]?.recovery?["queries"] as? [[String: Any]])?.count == 1,
          (bulk[name]?.recovery?["initial_status"] as? [String: Any])?["native_read_recovery"] == nil else {
        throw EngineError.message("Composite native bulk success fixture failed.")
    }
    let array = recoverNativeMetadataReads([name], initial: [name: original], batchQuery: {
        ReadResult(value: [kCFNull!] as CFArray, error: .success, attempts: 1)
    }, arrayQuery: { _, result in
        recoverNativeArray(result, count: { ReadResult(value: NSNumber(value: 0), error: .success, attempts: 1) }, values: { _, _ in throwawayArrayPage() })
    }, scalarQuery: { _, original in original })
    let arrayQueries = array[name]?.recovery?["queries"] as? [[String: Any]]
    guard array[name]?.error == .success, (array[name]?.value as? [Any])?.isEmpty == true, arrayQueries?.count == 2,
          array[name]?.recovery?["selected_method"] as? String == "AXUIElementGetAttributeValueCount/AXUIElementCopyAttributeValues",
          (arrayQueries?[1]["initial_status"] as? [String: Any])?["code"] as? Int32 == AXError.cannotComplete.rawValue,
          (arrayQueries?[1]["initial_status"] as? [String: Any])?["native_read_recovery"] == nil else {
        throw EngineError.message("Composite native empty-array fallback fixture failed.")
    }
    let scalar = recoverNativeMetadataReads([name], initial: [name: original], batchQuery: { ReadResult(value: [kCFNull!] as CFArray, error: .success, attempts: 1) },
                                            arrayQuery: { _, result in recoverNativeArray(result, count: { ReadResult(value: nil, error: .illegalArgument, attempts: 1) }, values: { _, _ in throwawayArrayPage() }) }, scalarQuery: { _, original in original })
    let scalarQueries = scalar[name]?.recovery?["queries"] as? [[String: Any]]
    guard scalar[name]?.error == .cannotComplete, scalar[name]?.attempts == 3, scalar[name]?.value == nil,
          scalar[name]?.recovery?["resolved"] as? Bool == false, scalar[name]?.recovery?["selected_method"] is NSNull,
          (scalarQueries?[1]["count_before_status"] as? [String: Any])?["code"] as? Int32 == AXError.illegalArgument.rawValue else {
        throw EngineError.message("Composite scalar array-query rejection fixture failed.")
    }
    let pageFailed = recoverNativeMetadataReads([name], initial: [name: original], batchQuery: { ReadResult(value: nil, error: .failure, attempts: 1) },
                                                arrayQuery: { _, result in recoverNativeArray(result, count: { ReadResult(value: NSNumber(value: 1), error: .success, attempts: 1) }, values: { _, _ in ReadResult(value: nil, error: .cannotComplete, attempts: 3) }) }, scalarQuery: { _, original in original })
    let pageQueries = pageFailed[name]?.recovery?["queries"] as? [[String: Any]]
    let pages = pageQueries?[1]["pages"] as? [[String: Any]]
    guard pageFailed[name]?.error == .cannotComplete, pageFailed[name]?.value == nil,
          (pages?.first?["status"] as? [String: Any])?["code"] as? Int32 == AXError.cannotComplete.rawValue else {
        throw EngineError.message("Composite native page failure evidence fixture failed.")
    }
    let unsupported = ReadResult<CFTypeRef>(value: nil, error: .attributeUnsupported, attempts: 1)
    let recoveredUnsupported = recoverNativeMetadataReads([name], initial: [name: unsupported], batchQuery: { ReadResult(value: nil, error: .failure, attempts: 1) },
                                                          arrayQuery: { _, result in recoverNativeArray(result, count: { ReadResult(value: NSNumber(value: 0), error: .success, attempts: 1) }, values: { _, _ in throwawayArrayPage() }) }, scalarQuery: { _, original in original })
    guard recoveredUnsupported[name]?.error == .success,
          (recoveredUnsupported[name]?.recovery?["initial_status"] as? [String: Any])?["code"] as? Int32 == AXError.attributeUnsupported.rawValue else {
        throw EngineError.message("Advertised unsupported-attribute native array recovery fixture failed.")
    }
    return 5
}

func nativeActionNamesRecoverySelfTest() throws -> Int {
    let initial = ReadResult<CFArray>(value: nil, error: .failure, attempts: 1)
    var fixtures = 0
    for names in [[], ["AXPress"]] {
        var calls = 0
        let result = recoverNativeActionNames(initial, query: { calls += 1; return ReadResult(value: names as CFArray, error: .success, attempts: 1) })
        guard calls == 1, result.error == .success, result.value as? [String] == names,
              result.recovery?["resolved"] as? Bool == true, result.recovery?["names_valid"] as? Bool == true,
              result.recovery?["returned_count"] as? Int == names.count else {
            throw EngineError.message("Native action-name genuine string-array recovery fixture failed.")
        }
        fixtures += 1
    }
    for query: ReadResult<CFArray> in [ReadResult(value: nil, error: .failure, attempts: 1),
                                     ReadResult(value: nil, error: .success, attempts: 1),
                                     ReadResult(value: ["AXPress", NSNumber(value: 0)] as CFArray, error: .success, attempts: 1),
                                     ReadResult(value: ["AXPress"] as CFArray, error: .attributeUnsupported, attempts: 1)] {
        let result = recoverNativeActionNames(initial, query: { query })
        guard result.error == .failure, result.value == nil, result.recovery?["resolved"] as? Bool == false else {
            throw EngineError.message("Native action-name failed/malformed recovery fixture failed.")
        }
        fixtures += 1
    }
    for untouched: ReadResult<CFArray> in [ReadResult(value: nil, error: .cannotComplete, attempts: 3),
                                         ReadResult(value: [] as CFArray, error: .success, attempts: 1)] {
        var calls = 0
        let result = recoverNativeActionNames(untouched, query: { calls += 1; return ReadResult(value: nil, error: .failure, attempts: 1) })
        guard calls == 0, result.error == untouched.error, result.recovery == nil else {
            throw EngineError.message("Native action-name non-failure query exclusion fixture failed.")
        }
        fixtures += 1
    }
    let presentFailure = ReadResult<CFArray>(value: ["AXPress"] as CFArray, error: .failure, attempts: 1)
    let stillFailed = recoverNativeActionNames(presentFailure, query: { ReadResult(value: nil, error: .failure, attempts: 1) })
    guard stillFailed.error == .failure, stillFailed.value as? [String] == ["AXPress"],
          nativeActionNamesForExport(stillFailed) == nil,
          stillFailed.recovery?["initial_has_array"] as? Bool == true,
          stillFailed.recovery?["initial_returned_count"] as? Int == 1 else {
        throw EngineError.message("Failed native action-name arrays were advertised or their returned evidence was discarded.")
    }
    fixtures += 1
    return fixtures
}

func nativeArrayRecoverySelfTest() throws -> Int {
    let original = ReadResult<CFTypeRef>(value: nil, error: .failure, attempts: 1)
    var pageCalls = 0
    let empty = recoverNativeArray(original, count: { ReadResult(value: NSNumber(value: 0), error: .success, attempts: 1) },
                                   values: { _, _ in pageCalls += 1; return ReadResult(value: nil, error: .failure, attempts: 1) })
    guard empty.error == .success, (empty.value as? [Any])?.isEmpty == true, pageCalls == 0,
          (empty.recovery?["initial_status"] as? [String: Any])?["code"] as? Int32 == AXError.failure.rawValue else {
        throw EngineError.message("Native array empty-count recovery fixture failed.")
    }
    let failedCount = recoverNativeArray(original, count: { ReadResult(value: nil, error: .failure, attempts: 1) },
                                         values: { _, _ in throwawayArrayPage() })
    guard failedCount.error == .failure, failedCount.value == nil, failedCount.recovery?["resolved"] as? Bool == false else {
        throw EngineError.message("Failed native count was incorrectly recovered.")
    }
    let full = (0..<600).map { NSNumber(value: $0) }
    let paged = recoverNativeArray(original, count: { ReadResult(value: NSNumber(value: 600), error: .success, attempts: 1) },
                                  values: { start, count in ReadResult(value: Array(full[start..<(start + count)]) as CFArray, error: .success, attempts: 1) })
    guard paged.error == .success, (paged.value as? [NSNumber]) == full,
          (paged.recovery?["pages"] as? [[String: Any]])?.count == 3 else { throw EngineError.message("Native array paging fixture failed.") }
    let short = recoverNativeArray(original, count: { ReadResult(value: NSNumber(value: 2), error: .success, attempts: 1) },
                                  values: { _, _ in ReadResult(value: [NSNumber(value: 1)] as CFArray, error: .success, attempts: 1) })
    let shortPages = short.recovery?["pages"] as? [[String: Any]]
    guard short.error == .failure, short.value == nil,
          shortPages?.first?["has_value"] as? Bool == true,
          shortPages?.first?["returned_count"] as? Int == 1 else {
        throw EngineError.message("Short native page was incorrectly accepted or its length was not retained.")
    }
    var countCalls = 0
    let changing = recoverNativeArray(original, count: { countCalls += 1; return ReadResult(value: NSNumber(value: countCalls == 1 ? 0 : 1), error: .success, attempts: 1) },
                                     values: { _, _ in throwawayArrayPage() })
    guard changing.error == .failure, changing.value == nil else { throw EngineError.message("Changing native count was incorrectly accepted.") }
    let invalid = ReadResult<CFTypeRef>(value: nil, error: .invalidUIElement, attempts: 1)
    var unexpectedCalls = 0
    let invalidResult = recoverNativeArray(invalid, count: { unexpectedCalls += 1; return ReadResult(value: NSNumber(value: 0), error: .success, attempts: 1) },
                                          values: { _, _ in throwawayArrayPage() })
    guard invalidResult.error == .invalidUIElement, unexpectedCalls == 0 else { throw EngineError.message("Invalid native handle was treated as an empty array.") }
    let pageError = recoverNativeArray(original, count: { ReadResult(value: NSNumber(value: 1), error: .success, attempts: 1) },
                                      values: { _, _ in ReadResult(value: nil, error: .cannotComplete, attempts: 3) })
    let failedPages = pageError.recovery?["pages"] as? [[String: Any]]
    guard pageError.error == .failure, pageError.value == nil,
          failedPages?.first?["has_value"] as? Bool == false,
          failedPages?.first?["returned_count"] is NSNull else {
        throw EngineError.message("Failed native page was incorrectly accepted or its absent value was not retained.")
    }
    let present = ReadResult<CFTypeRef>(value: [] as CFArray, error: .success, attempts: 1)
    let untouched = recoverNativeArray(present, count: { unexpectedCalls += 1; return ReadResult(value: nil, error: .failure, attempts: 1) },
                                      values: { _, _ in throwawayArrayPage() })
    guard untouched.error == .success, untouched.recovery == nil, unexpectedCalls == 0 else { throw EngineError.message("Successful array read was unnecessarily recovered.") }
    return 8
}

private func throwawayArrayPage() -> ReadResult<CFArray> {
    ReadResult(value: nil, error: .failure, attempts: 1)
}


let helperCounts = ["native_menu_reference_retry_fixtures": try nativeMenuReferenceRetrySelfTest(),
                    "native_scalar_recovery_fixtures": try nativeScalarRecoverySelfTest(),
                    "native_scalar_unsupported_retry_fixtures": try nativeScalarUnsupportedRetrySelfTest()]
let rootPID: pid_t = 47001, prefixPID: pid_t = 47002, ownerPID: pid_t = 47003
let root = AXUIElementCreateApplication(rootPID), prefix = AXUIElementCreateApplication(prefixPID)
let owner = AXUIElementCreateApplication(ownerPID), changed = AXUIElementCreateApplication(47004)
let endpoint = AXUIElementCreateApplication(47005)
let selector: [[String: Any]] = [["attribute": "AXChildren", "value_path": [0]], ["attribute": "AXChildren", "value_path": [0]]]
let roleRead = ReadResult<CFTypeRef>(value: "AXMenuItem" as CFString, error: .success, attempts: 1)
let original = ReadResult<CFTypeRef>(value: nil, error: .attributeUnsupported, attempts: 1)
var unsupported = AXError.attributeUnsupported, noValue = AXError.noValue
let unsupportedEnvelope = AXValueCreate(.axError, &unsupported)!, absenceEnvelope = AXValueCreate(.axError, &noValue)!
let goodStatus = ReadResult<CFTypeRef>(value: nil, error: .success, attempts: 1).status
func recorded(_ path: [[String: Any]]) -> (element: AXUIElement, pid: pid_t)? {
    if path.isEmpty { return (root, rootPID) }
    if canonical(path) == canonical(Array(selector.prefix(1))) { return (prefix, prefixPID) }
    if canonical(path) == canonical(selector) { return (owner, ownerPID) }
    return nil
}
func fresh(mode: String = "first_mismatch", readError: AXError = .success,
           pidError: AXError = .success, pidMismatch: Bool = false,
           process: Bool = true, timeout: AXError = .success) -> NativeScalarRefreshResult {
    refreshNativeScalarTarget(selectorPath: selector, rootPID: rootPID, expectedPID: ownerPID,
        recordedAtPath: recorded, processMatches: { _ in process }, createRoot: { mode == "root_changed" ? changed : root },
        setTimeout: { _ in timeout }, readAttribute: { current, _ in
            var value: CFTypeRef
            if mode == "missing_index" { value = [] as CFArray }
            else if mode == "wrong_type" { value = [kCFBooleanTrue!] as CFArray }
            else if CFEqual(current, root) { value = [mode == "first_mismatch" ? changed : prefix] as CFArray }
            else { value = [mode == "last_mismatch" ? changed : owner] as CFArray }
            return ReadResult(value: value, error: readError, attempts: 1)
        }, elementPID: { current in
            let expected = CFEqual(current, prefix) || mode == "first_mismatch" ? prefixPID : ownerPID
            return ReadResult(value: pidError == .success ? NSNumber(value: expected + (pidMismatch ? 1 : 0)) : nil,
                              error: pidError, attempts: 1)
        })
}
func retained(target: AXUIElement = owner, rootError: AXError = .success, ownerError: AXError = .success,
              rootNativePID: pid_t = rootPID, ownerNativePID: pid_t = ownerPID,
              process: (pid_t) -> Bool = { _ in true }) -> NativeScalarRefreshResult {
    validateRetainedNativeScalarTarget(nodeID: 2, rootID: 0, rootPID: rootPID, expectedPID: ownerPID,
        ownerRole: "AXMenuItem", ownerRoleStatus: roleRead.status, retainedOwner: target,
        recordedAtID: { id in id == 0 ? (root, rootPID) : id == 2 ? (owner, ownerPID) : nil },
        processMatches: process, elementPID: { current in
            let isRoot = CFEqual(current, root), error = isRoot ? rootError : ownerError
            return ReadResult(value: error == .success ? NSNumber(value: isRoot ? rootNativePID : ownerNativePID) : nil,
                              error: error, attempts: 1)
        })
}
var actualQueries = 0, actualRetainedValidations = 0
func composite(_ next: ReadResult<CFTypeRef>, attribute: String = "AXTopLevelUIElement",
               bulk: CFTypeRef = unsupportedEnvelope,
               refreshed: () -> NativeScalarRefreshResult = { fresh() },
               before: @escaping () -> NativeScalarRefreshResult = { retained() },
               after: @escaping () -> NativeScalarRefreshResult = { retained() },
               postIdentity: Bool = true) -> ReadResult<CFTypeRef> {
    actualQueries = 0; actualRetainedValidations = 0
    return recoverNativeMetadataReads([attribute], initial: [attribute: original],
        batchQuery: { ReadResult(value: [bulk] as CFArray, error: .success, attempts: 1) },
        arrayQuery: { _, _ in fatalError("Known scalar metadata must never use array queries") },
        scalarQuery: { name, initial in
            recoverNativeScalar(name, initial, refresh: refreshed, query: { target in
                precondition(CFEqual(target, owner), "Replacement menu references must never supply the query target")
                actualQueries += 1
                return next
            }, queryIdentityMatches: { postIdentity },
            retainedTarget: { actualRetainedValidations += 1; return before() },
            retainedQueryValidation: { target in
                precondition(CFEqual(target, owner), "Retained post-query checks must bind the same original handle")
                return after()
            })
        })[attribute]!
}
func encoded(_ value: CFTypeRef) -> Any {
    guard CFGetTypeID(value) == AXUIElementGetTypeID() else { fatalError("Only real native reference scalar values are exported by this fixture collection") }
    let ref = value as! AXUIElement
    let id = CFEqual(ref, root) ? 0 : CFEqual(ref, prefix) ? 1 : CFEqual(ref, owner) ? 2 : CFEqual(ref, endpoint) ? 3 : -1
    precondition(id >= 0, "All returned native references must have an explicit synthetic binding")
    return ["type": "AXUIElement", "id": id]
}
var cases: [[String: Any]] = []
var totalQueries = 0, totalRetainedQueries = 0, totalWithheld = 0, totalValues = 0, totalAbsences = 0
func record(_ label: String, _ result: ReadResult<CFTypeRef>, attribute: String = "AXTopLevelUIElement") {
    var attrs: [String: Any] = ["AXRole": "AXMenuItem"], statuses: [String: Any] = ["AXRole": roleRead.status, attribute: result.status]
    var recoveries: [String: Any] = [:], failures: [[String: Any]] = [], absent: [[String: Any]] = []
    if result.error == .success, let value = result.value { attrs[attribute] = encoded(value) }
    var valueCount = 0, absenceCount = 0, retainedCount = 0, withheld = 0, retainedValues = 0, retainedAbsences = 0
    if let trace = result.recovery {
        recoveries[attribute] = trace
        if trace["resolved"] as? Bool == true {
            if trace["resolution_kind"] as? String == "absence" { absenceCount = 1 } else { valueCount = 1 }
        }
        for query in trace["queries"] as? [[String: Any]] ?? [] where query["method"] as? String == "native_scalar_recovery" {
            if query["query_target"] as? String == "retained_original_reference", query["query_status"] is [String: Any] {
                retainedCount = 1
                if query["resolved"] as? Bool == true {
                    if query["resolution_kind"] as? String == "absence" { retainedAbsences = 1 }
                    else if query["resolution_kind"] as? String == "value" { retainedValues = 1 }
                }
            } else if query["retained_reference"] is [String: Any], query["query_status"] is NSNull { withheld = 1 }
        }
    }
    if result.error == .noValue { absent.append(["node": 2, "attribute": attribute, "status": result.status]) }
    else if result.error != .success { failures.append(["node": 2, "attribute": attribute, "stage": "attribute_read", "status": result.status]) }
    func identity(_ pid: pid_t, _ time: String) -> [String: Any] { ["pid": Int(pid), "launch_date": time, "fixture": "synthetic_captured_process_identity"] }
    let rootIdentity = identity(rootPID, "2026-10-10T00:00:00Z"), prefixIdentity = identity(prefixPID, "2026-10-10T00:00:01Z")
    let ownerIdentity = identity(ownerPID, "2026-10-10T00:00:02Z"), endpointIdentity = identity(47005, "2026-10-10T00:00:03Z")
    let rootNode: [String: Any] = ["id": 0, "pid": Int(rootPID), "process_identity": rootIdentity, "selector_path": [],
        "attribute_names": ["AXChildren"], "attributes": ["AXChildren": [["type": "AXUIElement", "id": 1]]],
        "attribute_statuses": ["AXChildren": goodStatus], "native_read_recoveries": [:], "action_names": [], "action_names_status": goodStatus]
    let prefixNode: [String: Any] = ["id": 1, "pid": Int(prefixPID), "process_identity": prefixIdentity, "selector_path": Array(selector.prefix(1)),
        "attribute_names": ["AXChildren"], "attributes": ["AXChildren": [["type": "AXUIElement", "id": 2]]],
        "attribute_statuses": ["AXChildren": goodStatus], "native_read_recoveries": [:], "action_names": [], "action_names_status": goodStatus]
    let ownerNode: [String: Any] = ["id": 2, "pid": Int(ownerPID), "process_identity": ownerIdentity, "selector_path": selector,
        "attribute_names": ["AXRole", attribute], "attributes": attrs, "attribute_statuses": statuses,
        "native_read_recoveries": recoveries, "action_names": [], "action_names_status": goodStatus]
    let endpointNode: [String: Any] = ["id": 3, "pid": 47005, "process_identity": endpointIdentity, "selector_path": [],
        "fixture": "synthetic_native_reference_endpoint_binding", "attribute_names": [], "attributes": [:], "attribute_statuses": [:],
        "native_read_recoveries": [:], "action_names": [], "action_names_status": goodStatus]
    let snapshot: [String: Any] = ["app": rootIdentity, "root_id": 0, "nodes": [rootNode, prefixNode, ownerNode, endpointNode], "node_count": 4,
        "metadata_classification_version": 2, "native_read_recovery_outcome_version": 2, "scalar_recovery_version": 3,
        "metadata_failures": failures, "metadata_read_failures": failures, "serialization_warnings": [], "absent_attribute_values": absent,
        "native_metadata_failure_summary": nativeMetadataFailureSummary(failures), "native_read_recovery_attempts": recoveries.count,
        "native_read_recovery_successes": valueCount + absenceCount, "native_read_recovery_value_successes": valueCount,
        "native_read_recovery_absence_successes": absenceCount, "native_scalar_retained_reference_attempts": retainedCount,
        "native_scalar_retained_reference_withheld": withheld, "native_scalar_retained_reference_value_successes": retainedValues,
        "native_scalar_retained_reference_absence_successes": retainedAbsences,
        "scope": ["hierarchy_attributes": ["AXChildren", "AXWindows", "AXRows", "AXColumns"]]]
    cases.append(["label": label, "snapshot": snapshot, "actual_scalar_calls": actualQueries, "actual_retained_before_validations": actualRetainedValidations])
    totalQueries += actualQueries; totalRetainedQueries += retainedCount; totalWithheld += withheld
    totalValues += valueCount; totalAbsences += absenceCount
}
let typed = ReadResult<CFTypeRef>(value: endpoint, error: .success, attempts: 1)
record("isolated_intermediate_menu_wrapper_mismatch_original_reference_typed", composite(typed))
record("retained_explicit_native_noValue_drops_untrusted_ref", composite(ReadResult(value: changed, error: .noValue, attempts: 1)))
record("retained_still_unsupported", composite(ReadResult(value: owner, error: .attributeUnsupported, attempts: 1)))
record("retained_native_owner_no_longer_live", composite(ReadResult(value: nil, error: .invalidUIElement, attempts: 1)))
record("retained_nil_success_is_unresolved", composite(ReadResult(value: nil, error: .success, attempts: 1)))
record("retained_wrong_native_scalar_type", composite(ReadResult(value: [] as CFArray, error: .success, attempts: 1)))
let afterCases: [(String, () -> NativeScalarRefreshResult)] = [
    ("post_query_owner_native_PID_failure", { retained(ownerError: .invalidUIElement) }),
    ("post_query_root_native_PID_failure", { retained(rootError: .invalidUIElement) }),
    ("post_query_owner_native_PID_changed", { retained(ownerNativePID: ownerPID + 1) }),
    ("post_query_owner_launch_changed", { retained(process: { $0 != ownerPID }) }),
    ("post_query_root_launch_changed", { retained(process: { $0 != rootPID }) })]
for (label, after) in afterCases { record(label, composite(typed, after: after)) }
record("existing_post_query_identity_guard_remains_required", composite(typed, postIdentity: false))
let beforeCases: [(String, () -> NativeScalarRefreshResult)] = [
    ("retained_registry_binding_swapped_before_query", { retained(target: changed) }),
    ("retained_root_native_PID_failure_before_query", { retained(rootError: .invalidUIElement) }),
    ("retained_owner_native_PID_failure_before_query", { retained(ownerError: .invalidUIElement) }),
    ("retained_root_native_PID_changed_before_query", { retained(rootNativePID: rootPID + 1) }),
    ("retained_owner_native_PID_changed_before_query", { retained(ownerNativePID: ownerPID + 1) }),
    ("retained_root_launch_changed_before_query", { retained(process: { $0 != rootPID }) }),
    ("retained_owner_launch_changed_before_query", { retained(process: { $0 != ownerPID }) })]
for (label, before) in beforeCases { record(label, composite(typed, before: before)) }
let refreshCases: [(String, () -> NativeScalarRefreshResult)] = [
    ("fresh_root_not_CFEqual_no_retained_route", { fresh(mode: "root_changed") }),
    ("fresh_native_prefix_read_failed_no_retained_route", { fresh(readError: .failure) }),
    ("fresh_native_value_path_missing_no_retained_route", { fresh(mode: "missing_index") }),
    ("fresh_native_selected_type_wrong_no_retained_route", { fresh(mode: "wrong_type") }),
    ("fresh_native_prefix_PID_failed_no_retained_route", { fresh(pidError: .invalidUIElement) }),
    ("fresh_native_prefix_PID_changed_no_retained_route", { fresh(pidMismatch: true) }),
    ("fresh_native_launch_identity_changed_no_retained_route", { fresh(process: false) }),
    ("fresh_native_timeout_failed_no_retained_route", { fresh(timeout: .failure) })]
for (label, refreshed) in refreshCases { record(label, composite(typed, refreshed: refreshed)) }
record("normal_fresh_exact_reference_typed_query", composite(typed, refreshed: { fresh(mode: "exact") }))
record("normal_fresh_exact_reference_explicit_absence", composite(ReadResult(value: nil, error: .noValue, attempts: 1), refreshed: { fresh(mode: "exact") }))
record("last_menu_prefix_mismatch_after_verified_ancestor_typed", composite(typed, refreshed: { fresh(mode: "last_mismatch") }))
record("last_menu_prefix_mismatch_original_reference_still_unsupported", composite(ReadResult(value: nil, error: .attributeUnsupported, attempts: 1), refreshed: { fresh(mode: "last_mismatch") }))
var processChecks = 0
record("launch_changes_during_retained_native_PID_validation", composite(typed, before: { retained(process: { _ in processChecks += 1; return processChecks < 3 }) }))
record("correct_bulk_native_value_needs_no_scalar_query", composite(typed, bulk: endpoint))
record("confirmed_bulk_native_absence_needs_no_scalar_query", composite(typed, bulk: absenceEnvelope))
record("other_scalar_attribute_mismatch_never_uses_retained_route", composite(typed, attribute: "AXGrowArea"), attribute: "AXGrowArea")
let artifact: [String: Any] = ["fixture_kind": "offline_independent_native_menu_reference_retry_cases",
    "fixture_scope": "Independent synthetic caller contexts execute actual Swift helpers using constructor-only native objects and mocked native reads/PID/launch callbacks. Saved root/prefix/owner selectors and original registry bindings are consistent per case. Changed wrappers are never used as scalar query targets. These are offline helper cases, not a captured native app graph; no native application messaging, UI actions, app restarts or permission changes occurred.",
    "helper_fixture_counts": helperCounts, "cases": cases, "case_count": cases.count,
    "total_scalar_calls": totalQueries, "total_retained_scalar_calls": totalRetainedQueries, "total_retained_queries_withheld": totalWithheld,
    "total_value_resolutions": totalValues, "total_absence_resolutions": totalAbsences]
let output = URL(fileURLWithPath: "/Users/ahmedelamin/Documents/Codex/2026-10-09/i-ha/native-ax-engine/artifacts/native-menu-reference-retry-20261010/native-query-fixtures.json")
try JSONSerialization.data(withJSONObject: artifact, options: [.prettyPrinted, .sortedKeys]).write(to: output, options: .atomic)
print(String(data: try JSONSerialization.data(withJSONObject: ["artifact": output.path, "cases": cases.count, "native_menu_reference_retry_fixtures": helperCounts["native_menu_reference_retry_fixtures"]!, "scalar_calls": totalQueries, "retained_calls": totalRetainedQueries, "withheld": totalWithheld, "values": totalValues, "absences": totalAbsences], options: [.sortedKeys]), encoding: .utf8)!)
