import Foundation
import ApplicationServices
enum EngineError: Error { case message(String) }
let retryLimit = 2
func errorName(_ error: AXError) -> String {
    switch error {
    case .success: return "success"
    case .failure: return "failure"
    case .illegalArgument: return "illegalArgument"
    case .invalidUIElement: return "invalidUIElement"
    case .invalidUIElementObserver: return "invalidUIElementObserver"
    case .cannotComplete: return "cannotComplete"
    case .attributeUnsupported: return "attributeUnsupported"
    case .actionUnsupported: return "actionUnsupported"
    case .notificationUnsupported: return "notificationUnsupported"
    case .notImplemented: return "notImplemented"
    case .notificationAlreadyRegistered: return "notificationAlreadyRegistered"
    case .notificationNotRegistered: return "notificationNotRegistered"
    case .apiDisabled: return "apiDisabled"
    case .noValue: return "noValue"
    case .parameterizedAttributeUnsupported: return "parameterizedAttributeUnsupported"
    case .notEnoughPrecision: return "notEnoughPrecision"
    @unknown default: return "unknown"
    }
}

struct ReadResult<T> {
    let value: T?
    let error: AXError
    let attempts: Int
    var recovery: [String: Any]? = nil
    var status: [String: Any] {
        var result: [String: Any] = ["code": error.rawValue, "name": errorName(error), "attempts": attempts]
        if let recovery { result["native_read_recovery"] = recovery }
        return result
    }
}

func nativeReadStatus<T>(_ result: ReadResult<T>) -> [String: Any] {
    ["code": result.error.rawValue, "name": errorName(result.error), "attempts": result.attempts]
}

func nativeMetadataRecoveryEligible(_ error: AXError) -> Bool {
    error == .failure || error == .cannotComplete || error == .attributeUnsupported
}

func read<T>(_ operation: (inout T?) -> AXError) -> ReadResult<T> {
    var finalError = AXError.failure
    var finalValue: T?
    var attempts = 0
    for _ in 0...retryLimit {
        attempts += 1
        finalValue = nil
        finalError = operation(&finalValue)
        if finalError != .cannotComplete { break }
    }
    return ReadResult(value: finalValue, error: finalError, attempts: attempts)
}

func recoverNativeArray(_ initial: ReadResult<CFTypeRef>,
                        count: () -> ReadResult<NSNumber>,
                        values: (Int, Int) -> ReadResult<CFArray>) -> ReadResult<CFTypeRef> {
    // A failed read is never relabeled as an empty selection. Recovery needs
    // successful native array-count and page reads, with the count checked
    // again afterwards. The original failure remains in the recovery trace.
    guard nativeMetadataRecoveryEligible(initial.error) else { return initial }
    var trace: [String: Any] = ["method": "AXUIElementGetAttributeValueCount/AXUIElementCopyAttributeValues",
                              "initial_status": nativeReadStatus(initial), "resolved": false, "resolution_kind": "unresolved"]
    func failed(_ reason: String) -> ReadResult<CFTypeRef> {
        trace["reason"] = reason
        return ReadResult(value: initial.value, error: initial.error, attempts: initial.attempts, recovery: trace)
    }
    let before = count()
    trace["count_before_status"] = before.status
    guard before.error == .success, let beforeValue = before.value else { return failed("Native array count could not be read.") }
    let expected = beforeValue.intValue
    trace["count_before"] = expected
    guard expected >= 0 else { return failed("Native array count was negative.") }
    var result: [Any] = [], pages: [[String: Any]] = []
    while result.count < expected {
        let start = result.count, requested = min(256, expected - start)
        let page = values(start, requested)
        let items = page.value as? [Any]
        pages.append(["index": start, "requested": requested, "status": page.status,
                      "has_value": page.value != nil, "returned_count": items?.count ?? NSNull()])
        trace["pages"] = pages
        guard page.error == .success, let array = items, array.count == requested else {
            return failed("Native array page failed or its length changed during reading.")
        }
        result.append(contentsOf: array)
    }
    let after = count()
    trace["count_after_status"] = after.status
    trace["count_after"] = after.value ?? NSNull()
    guard after.error == .success, after.value?.intValue == expected else {
        return failed("Native array count changed or could not be confirmed after reading.")
    }
    trace["resolved"] = true
    trace["resolution_kind"] = "value"
    trace["returned_count"] = result.count
    return ReadResult(value: result as CFArray, error: .success, attempts: initial.attempts, recovery: trace)
}

func attribute(_ element: AXUIElement, _ name: String) -> ReadResult<CFTypeRef> {
    read { AXUIElementCopyAttributeValue(element, name as CFString, &$0) }
}

func recoverNativeMetadataBatch(_ names: [String], initial: [String: ReadResult<CFTypeRef>],
                                query: () -> ReadResult<CFArray>,
                                decodeError: (AXValue) -> AXError? = { value in
                                    var error = AXError.success
                                    return AXValueGetValue(value, .axError, &error) ? error : nil
                                }) -> [String: ReadResult<CFTypeRef>] {
    guard !names.isEmpty else { return [:] }
    let batch = query()
    let items = batch.value as? [Any]
    let validSelection = Set(names).count == names.count && names.allSatisfy { initial[$0] != nil }
    var results: [String: ReadResult<CFTypeRef>] = [:]
    for (index, name) in names.enumerated() {
        guard let original = initial[name] else { continue }
        var trace: [String: Any] = ["method": "AXUIElementCopyMultipleAttributeValues", "query_attributes": names,
                                   "options": 0, "query_status": nativeReadStatus(batch), "has_array": batch.value != nil,
                                   "returned_slot_count": items?.count ?? NSNull(), "slot_index": index,
                                   "slot_attribute": name, "item_kind": "malformed", "item_status": NSNull(),
                                   "item_error_decoded": false, "cf_type_id": NSNull(), "resolved": false,
                                   "resolution_kind": "unresolved"]
        func unresolved(_ reason: String) -> ReadResult<CFTypeRef> {
            trace["reason"] = reason
            return ReadResult(value: original.value, error: original.error, attempts: original.attempts, recovery: trace)
        }
        guard validSelection else { results[name] = unresolved("Batch attribute selection was not unique or lacked matching original reads."); continue }
        guard batch.error == .success else { results[name] = unresolved("Native bulk attribute query failed; the original attribute error is retained."); continue }
        guard let items else { results[name] = unresolved("Native bulk query returned no usable array."); continue }
        guard items.count == names.count else { results[name] = unresolved("Native bulk result cardinality does not match the exact ordered query attributes."); continue }
        let item = items[index] as CFTypeRef
        let type = CFGetTypeID(item)
        trace["cf_type_id"] = Int(type)
        if type == CFNullGetTypeID() {
            trace["item_kind"] = "null"
            results[name] = unresolved("Native bulk slot was CFNull, not an attribute value.")
            continue
        }
        if type == AXValueGetTypeID(), AXValueGetType(item as! AXValue) == .axError {
            trace["item_kind"] = "ax_error"
            if let error = decodeError(item as! AXValue) {
                trace["item_error_decoded"] = true
                trace["item_status"] = ["code": error.rawValue, "name": errorName(error)]
                if error == .noValue {
                    // An exact successful options=0 bulk slot explicitly reports
                    // native absence. It is not an empty value or a failed read.
                    trace["resolved"] = true
                    trace["resolution_kind"] = "absence"
                    results[name] = ReadResult(value: nil, error: .noValue, attempts: original.attempts, recovery: trace)
                } else {
                    results[name] = unresolved("Native bulk slot contained an AX error envelope; the per-slot error and original query error are retained.")
                }
            } else {
                results[name] = unresolved("Native bulk AX error envelope could not be decoded.")
            }
            continue
        }
        trace["item_kind"] = "value"
        trace["resolved"] = true
        trace["resolution_kind"] = "value"
        results[name] = ReadResult(value: item, error: .success, attempts: original.attempts, recovery: trace)
    }
    return results
}

func recoverNativeMetadataReads(_ names: [String], initial: [String: ReadResult<CFTypeRef>],
                                batchQuery: () -> ReadResult<CFArray>,
                                arrayQuery: (String, ReadResult<CFTypeRef>) -> ReadResult<CFTypeRef>) -> [String: ReadResult<CFTypeRef>] {
    let bulkResults = recoverNativeMetadataBatch(names, initial: initial, query: batchQuery)
    var results: [String: ReadResult<CFTypeRef>] = [:]
    for name in names {
        guard let original = initial[name], let bulk = bulkResults[name] else { continue }
        var queries: [[String: Any]] = []
        if let trace = bulk.recovery { queries.append(trace) }
        var selected = bulk
        var selectedMethod: Any = NSNull()
        let bulkAbsence = bulk.error == .noValue && bulk.value == nil &&
            bulk.recovery?["resolved"] as? Bool == true && bulk.recovery?["resolution_kind"] as? String == "absence"
        if (bulk.error == .success && bulk.value != nil) || bulkAbsence {
            selectedMethod = "AXUIElementCopyMultipleAttributeValues"
        } else {
            let array = arrayQuery(name, original)
            if let trace = array.recovery { queries.append(trace) }
            if array.error == .success, array.value != nil {
                selected = array
                selectedMethod = "AXUIElementGetAttributeValueCount/AXUIElementCopyAttributeValues"
            }
        }
        let absence = selected.error == .noValue && selected.value == nil &&
            selected.recovery?["resolved"] as? Bool == true && selected.recovery?["resolution_kind"] as? String == "absence"
        let value = selected.error == .success && selected.value != nil
        let resolved = value || absence
        let composite: [String: Any] = ["method": "native_metadata_recovery", "initial_status": nativeReadStatus(original),
                                       "queries": queries, "resolved": resolved, "selected_method": selectedMethod,
                                       "resolution_kind": absence ? "absence" : value ? "value" : "unresolved"]
        results[name] = ReadResult(value: absence ? nil : value ? selected.value : original.value,
                                  error: absence ? .noValue : value ? .success : original.error,
                                  attempts: original.attempts, recovery: composite)
    }
    return results
}

func recoverNativeActionNames(_ initial: ReadResult<CFArray>, query: () -> ReadResult<CFArray>) -> ReadResult<CFArray> {
    guard initial.error == .failure else { return initial }
    let next = query()
    let items = next.value as? [Any]
    let names = next.value as? [String]
    let resolved = next.error == .success && names != nil
    var trace: [String: Any] = ["method": "native_action_names_recovery", "initial_status": nativeReadStatus(initial),
                              "initial_has_array": initial.value != nil,
                              "initial_returned_count": (initial.value as? [Any])?.count ?? NSNull(),
                              "query_status": nativeReadStatus(next), "has_array": next.value != nil,
                              "returned_count": items?.count ?? NSNull(), "names_valid": names != nil,
                              "strings_count": items?.filter { $0 is String }.count ?? NSNull(), "resolved": resolved,
                              "resolution_kind": resolved ? "value" : "unresolved"]
    if !resolved { trace["reason"] = "The bounded fresh action-name query did not return a successful native string array." }
    return ReadResult(value: resolved ? next.value : initial.value, error: resolved ? .success : initial.error,
                      attempts: initial.attempts, recovery: trace)
}

func nativeActionNamesForExport(_ result: ReadResult<CFArray>) -> [String]? {
    guard result.error == .success else { return nil }
    return result.value as? [String]
}

func nativeMetadataBatchRecoverySelfTest() throws -> Int {
    func check(_ condition: Bool, _ message: String) throws {
        if !condition { throw EngineError.message("Native bulk metadata fixture failed: \(message)") }
    }
    func initial(_ names: [String], error: AXError = .failure) -> [String: ReadResult<CFTypeRef>] {
        Dictionary(uniqueKeysWithValues: names.map { ($0, ReadResult(value: nil, error: error, attempts: error == .cannotComplete ? 3 : 1)) })
    }
    func envelope(_ error: AXError) -> AXValue {
        var error = error
        return AXValueCreate(.axError, &error)!
    }
    var fixtures = 0
    let names = ["AXEnabled", "AXValue", "AXSelectedTextRanges", "AXDescription", "AXHelp", "AXPosition"]
    var point = CGPoint(x: 2, y: 3)
    let nativePoint = AXValueCreate(.cgPoint, &point)!
    let mixed: [Any] = [kCFBooleanFalse!, NSNumber(value: 0), [] as CFArray, kCFNull!, envelope(.attributeUnsupported), nativePoint]
    var queryCalls = 0
    let recovered = recoverNativeMetadataBatch(names, initial: initial(names), query: {
        queryCalls += 1; return ReadResult(value: mixed as CFArray, error: .success, attempts: 1)
    })
    try check(queryCalls == 1 && recovered["AXEnabled"]?.error == .success &&
              (recovered["AXEnabled"]?.value as? NSNumber)?.boolValue == false &&
              recovered["AXValue"]?.error == .success && (recovered["AXValue"]?.value as? NSNumber)?.intValue == 0 &&
              recovered["AXSelectedTextRanges"]?.error == .success && (recovered["AXSelectedTextRanges"]?.value as? [Any])?.isEmpty == true &&
              recovered["AXDescription"]?.error == .failure && recovered["AXDescription"]?.recovery?["item_kind"] as? String == "null" &&
              recovered["AXHelp"]?.error == .failure && recovered["AXHelp"]?.recovery?["item_error_decoded"] as? Bool == true &&
              (recovered["AXHelp"]?.recovery?["item_status"] as? [String: Any])?["code"] as? Int32 == AXError.attributeUnsupported.rawValue &&
              recovered["AXPosition"]?.error == .success, "mixed native values, null, and error envelopes remain distinct")
    fixtures += 1
    let one = ["AXTitle"]
    let outerFailure = recoverNativeMetadataBatch(one, initial: initial(one), query: {
        ReadResult(value: ["Native title"] as CFArray, error: .cannotComplete, attempts: 1)
    })
    try check(outerFailure["AXTitle"]?.error == .failure && outerFailure["AXTitle"]?.value == nil &&
              (outerFailure["AXTitle"]?.recovery?["query_status"] as? [String: Any])?["code"] as? Int32 == AXError.cannotComplete.rawValue,
              "an outer query error never turns a returned slot into success")
    fixtures += 1
    let nilArray = recoverNativeMetadataBatch(one, initial: initial(one), query: { ReadResult(value: nil, error: .success, attempts: 1) })
    try check(nilArray["AXTitle"]?.error == .failure && nilArray["AXTitle"]?.recovery?["has_array"] as? Bool == false &&
              nilArray["AXTitle"]?.recovery?["returned_slot_count"] is NSNull, "success with nil is unresolved")
    fixtures += 1
    let two = ["AXTitle", "AXDescription"]
    for payload: [Any] in [["only-one"], ["one", "two", "unexpected-third"]] {
        let cardinality = recoverNativeMetadataBatch(two, initial: initial(two), query: { ReadResult(value: payload as CFArray, error: .success, attempts: 1) })
        try check(cardinality.values.allSatisfy { $0.error == .failure && $0.value == nil && $0.recovery?["resolved"] as? Bool == false },
                  "a cardinality mismatch invalidates every slot mapping")
        fixtures += 1
    }
    let ordered = recoverNativeMetadataBatch(two, initial: initial(two), query: { ReadResult(value: ["first", "second"] as CFArray, error: .success, attempts: 1) })
    try check(ordered["AXTitle"]?.value as? String == "first" && ordered["AXDescription"]?.value as? String == "second" &&
              ordered["AXTitle"]?.recovery?["query_attributes"] as? [String] == two, "native slots preserve exact query order")
    fixtures += 1
    let null = recoverNativeMetadataBatch(one, initial: initial(one), query: { ReadResult(value: [kCFNull!] as CFArray, error: .success, attempts: 1) })
    try check(null["AXTitle"]?.error == .failure && null["AXTitle"]?.recovery?["item_kind"] as? String == "null" &&
              null["AXTitle"]?.recovery?["cf_type_id"] as? Int == Int(CFNullGetTypeID()), "CFNull retains its native runtime type and is not an empty value")
    fixtures += 1
    for error: AXError in [.noValue, .illegalArgument, .failure, .cannotComplete, .success] {
        let item = recoverNativeMetadataBatch(one, initial: initial(one), query: { ReadResult(value: [envelope(error)] as CFArray, error: .success, attempts: 1) })
        try check(item["AXTitle"]?.error == (error == .noValue ? .noValue : .failure) && item["AXTitle"]?.value == nil &&
                  item["AXTitle"]?.recovery?["item_error_decoded"] as? Bool == true &&
                  (item["AXTitle"]?.recovery?["item_status"] as? [String: Any])?["code"] as? Int32 == error.rawValue &&
                  item["AXTitle"]?.recovery?["resolution_kind"] as? String == (error == .noValue ? "absence" : "unresolved"),
                  "decoded noValue confirms absence; other error envelopes retain the original failure without inventing a value")
        fixtures += 1
    }
    let unreadable = recoverNativeMetadataBatch(one, initial: initial(one), query: { ReadResult(value: [envelope(.failure)] as CFArray, error: .success, attempts: 1) }, decodeError: { _ in nil })
    try check(unreadable["AXTitle"]?.error == .failure && unreadable["AXTitle"]?.recovery?["item_error_decoded"] as? Bool == false &&
              unreadable["AXTitle"]?.recovery?["item_status"] is NSNull, "undecodable error envelopes stay unresolved")
    fixtures += 1
    queryCalls = 0
    let absent = recoverNativeMetadataBatch([], initial: [:], query: { queryCalls += 1; return ReadResult(value: nil, error: .failure, attempts: 1) })
    try check(absent.isEmpty && queryCalls == 0, "no failed candidates means no bulk query")
    fixtures += 1
    return fixtures
}

func nativeAbsenceRecoverySelfTest() throws -> Int {
    func check(_ condition: Bool, _ message: String) throws {
        if !condition { throw EngineError.message("Native absence recovery fixture failed: \(message)") }
    }
    func envelope(_ error: AXError) -> AXValue {
        var error = error
        return AXValueCreate(.axError, &error)!
    }
    let name = "AXHelp"
    let initial = ReadResult<CFTypeRef>(value: nil, error: .failure, attempts: 1)
    let noValue = envelope(.noValue)
    var fixtures = 0
    let bulk = recoverNativeMetadataBatch([name], initial: [name: initial], query: {
        ReadResult(value: [noValue] as CFArray, error: .success, attempts: 1)
    })[name]!
    try check(bulk.error == .noValue && bulk.value == nil && bulk.attempts == 1 &&
              bulk.recovery?["resolved"] as? Bool == true && bulk.recovery?["resolution_kind"] as? String == "absence" &&
              bulk.recovery?["item_kind"] as? String == "ax_error" && bulk.recovery?["item_error_decoded"] as? Bool == true &&
              (bulk.recovery?["item_status"] as? [String: Any])?["code"] as? Int32 == AXError.noValue.rawValue,
              "an exact native noValue slot confirms absence with its real envelope evidence")
    fixtures += 1
    var arrayCalls = 0
    func composite(_ original: ReadResult<CFTypeRef>, payload: CFArray? = [noValue] as CFArray,
                   error: AXError = .success) -> ReadResult<CFTypeRef> {
        recoverNativeMetadataReads([name], initial: [name: original], batchQuery: {
            ReadResult(value: payload, error: error, attempts: 1)
        }, arrayQuery: { _, result in
            arrayCalls += 1
            return recoverNativeArray(result, count: { ReadResult(value: nil, error: .illegalArgument, attempts: 1) },
                                      values: { _, _ in throwawayArrayPage() })
        })[name]!
    }
    let cannotComplete = ReadResult<CFTypeRef>(value: nil, error: .cannotComplete, attempts: 3)
    let terminal = composite(cannotComplete)
    try check(terminal.error == .noValue && terminal.value == nil && terminal.attempts == 3 && arrayCalls == 0 &&
              terminal.recovery?["resolution_kind"] as? String == "absence" &&
              terminal.recovery?["selected_method"] as? String == "AXUIElementCopyMultipleAttributeValues" &&
              (terminal.recovery?["queries"] as? [[String: Any]])?.count == 1 &&
              (terminal.recovery?["initial_status"] as? [String: Any])?["code"] as? Int32 == AXError.cannotComplete.rawValue,
              "confirmed absence is terminal and retains the original failed read and attempts")
    fixtures += 1
    let untrusted = ReadResult<CFTypeRef>(value: kCFBooleanTrue!, error: .failure, attempts: 1)
    let discarded = composite(untrusted)
    try check(discarded.error == .noValue && discarded.value == nil && arrayCalls == 0,
              "confirmed absence drops any value accompanying the original failed read")
    fixtures += 1
    let empty = composite(initial, payload: [[] as CFArray] as CFArray)
    try check(empty.error == .success && (empty.value as? [Any])?.isEmpty == true &&
              empty.recovery?["resolution_kind"] as? String == "value" && arrayCalls == 0,
              "a genuine empty array remains a native value rather than absence")
    fixtures += 1
    for (payload, error): (CFArray?, AXError) in [([] as CFArray, .success),
                                                ([noValue, noValue] as CFArray, .success),
                                                ([noValue] as CFArray, .failure), (nil, .success)] {
        let result = composite(initial, payload: payload, error: error)
        try check(result.error == .failure && result.value == nil && result.recovery?["resolved"] as? Bool == false &&
                  result.recovery?["resolution_kind"] as? String == "unresolved",
                  "outer failure, nil, or invalid cardinality cannot confirm a noValue slot")
        fixtures += 1
    }
    let null = composite(initial, payload: [kCFNull!] as CFArray)
    try check(null.error == .failure && null.value == nil && null.recovery?["resolution_kind"] as? String == "unresolved",
              "CFNull is not native noValue evidence")
    fixtures += 1
    for error: AXError in [.success, .attributeUnsupported] {
        let result = recoverNativeMetadataBatch([name], initial: [name: initial], query: {
            ReadResult(value: [envelope(error)] as CFArray, error: .success, attempts: 1)
        })[name]!
        try check(result.error == .failure && result.value == nil && result.recovery?["resolution_kind"] as? String == "unresolved",
                  "success or unsupported error envelopes do not become absence or content")
        fixtures += 1
    }
    let undecodable = recoverNativeMetadataBatch([name], initial: [name: initial], query: {
        ReadResult(value: [noValue] as CFArray, error: .success, attempts: 1)
    }, decodeError: { _ in nil })[name]!
    try check(undecodable.error == .failure && undecodable.value == nil &&
              undecodable.recovery?["resolution_kind"] as? String == "unresolved" &&
              undecodable.recovery?["item_error_decoded"] as? Bool == false,
              "an undecodable native error envelope cannot confirm absence")
    fixtures += 1
    let names = ["AXHelp", "AXSelectedTextRanges"]
    let mixed = recoverNativeMetadataBatch(names, initial: [names[0]: initial, names[1]: initial], query: {
        ReadResult(value: [noValue, [] as CFArray] as CFArray, error: .success, attempts: 1)
    })
    try check(mixed[names[0]]?.error == .noValue && mixed[names[0]]?.value == nil &&
              mixed[names[0]]?.recovery?["slot_index"] as? Int == 0 &&
              mixed[names[1]]?.error == .success && (mixed[names[1]]?.value as? [Any])?.isEmpty == true &&
              mixed[names[1]]?.recovery?["resolution_kind"] as? String == "value" &&
              mixed[names[1]]?.recovery?["slot_index"] as? Int == 1,
              "exact mixed slots preserve independent absence and real empty-array outcomes")
    fixtures += 1
    let pagedEmpty = recoverNativeArray(initial, count: { ReadResult(value: NSNumber(value: 0), error: .success, attempts: 1) },
                                       values: { _, _ in throwawayArrayPage() })
    try check(pagedEmpty.error == .success && pagedEmpty.recovery?["resolution_kind"] as? String == "value",
              "native count-confirmed empty arrays resolve as values")
    fixtures += 1
    let actions = recoverNativeActionNames(ReadResult(value: nil, error: .failure, attempts: 1), query: {
        ReadResult(value: [] as CFArray, error: .success, attempts: 1)
    })
    try check(actions.error == .success && actions.recovery?["resolution_kind"] as? String == "value",
              "native empty action-name arrays resolve as values")
    fixtures += 1
    let unsupported = composite(ReadResult(value: nil, error: .attributeUnsupported, attempts: 1))
    try check(unsupported.error == .noValue && unsupported.value == nil &&
              unsupported.recovery?["resolution_kind"] as? String == "absence" &&
              (unsupported.recovery?["queries"] as? [[String: Any]])?.count == 1 && arrayCalls == 5,
              "an advertised unsupported original read may be resolved by exact noValue evidence without another array query")
    fixtures += 1
    return fixtures
}

func nativeMetadataCompositeRecoverySelfTest() throws -> Int {
    let name = "AXSelectedTextRanges"
    let original = ReadResult<CFTypeRef>(value: nil, error: .cannotComplete, attempts: 3)
    var arrayCalls = 0
    let bulk = recoverNativeMetadataReads([name], initial: [name: original], batchQuery: {
        ReadResult(value: [kCFBooleanFalse!] as CFArray, error: .success, attempts: 1)
    }, arrayQuery: { _, result in arrayCalls += 1; return result })
    guard arrayCalls == 0, bulk[name]?.error == .success, bulk[name]?.attempts == 3,
          bulk[name]?.recovery?["method"] as? String == "native_metadata_recovery",
          bulk[name]?.recovery?["selected_method"] as? String == "AXUIElementCopyMultipleAttributeValues",
          (bulk[name]?.recovery?["queries"] as? [[String: Any]])?.count == 1,
          (bulk[name]?.recovery?["initial_status"] as? [String: Any])?["native_read_recovery"] == nil else {
        throw EngineError.message("Composite native bulk success fixture failed.")
    }
    let array = recoverNativeMetadataReads([name], initial: [name: original], batchQuery: {
        ReadResult(value: [kCFNull!] as CFArray, error: .success, attempts: 1)
    }, arrayQuery: { _, result in
        recoverNativeArray(result, count: { ReadResult(value: NSNumber(value: 0), error: .success, attempts: 1) }, values: { _, _ in throwawayArrayPage() })
    })
    let arrayQueries = array[name]?.recovery?["queries"] as? [[String: Any]]
    guard array[name]?.error == .success, (array[name]?.value as? [Any])?.isEmpty == true, arrayQueries?.count == 2,
          array[name]?.recovery?["selected_method"] as? String == "AXUIElementGetAttributeValueCount/AXUIElementCopyAttributeValues",
          (arrayQueries?[1]["initial_status"] as? [String: Any])?["code"] as? Int32 == AXError.cannotComplete.rawValue,
          (arrayQueries?[1]["initial_status"] as? [String: Any])?["native_read_recovery"] == nil else {
        throw EngineError.message("Composite native empty-array fallback fixture failed.")
    }
    let scalar = recoverNativeMetadataReads([name], initial: [name: original], batchQuery: { ReadResult(value: [kCFNull!] as CFArray, error: .success, attempts: 1) },
                                            arrayQuery: { _, result in recoverNativeArray(result, count: { ReadResult(value: nil, error: .illegalArgument, attempts: 1) }, values: { _, _ in throwawayArrayPage() }) })
    let scalarQueries = scalar[name]?.recovery?["queries"] as? [[String: Any]]
    guard scalar[name]?.error == .cannotComplete, scalar[name]?.attempts == 3, scalar[name]?.value == nil,
          scalar[name]?.recovery?["resolved"] as? Bool == false, scalar[name]?.recovery?["selected_method"] is NSNull,
          (scalarQueries?[1]["count_before_status"] as? [String: Any])?["code"] as? Int32 == AXError.illegalArgument.rawValue else {
        throw EngineError.message("Composite scalar array-query rejection fixture failed.")
    }
    let pageFailed = recoverNativeMetadataReads([name], initial: [name: original], batchQuery: { ReadResult(value: nil, error: .failure, attempts: 1) },
                                                arrayQuery: { _, result in recoverNativeArray(result, count: { ReadResult(value: NSNumber(value: 1), error: .success, attempts: 1) }, values: { _, _ in ReadResult(value: nil, error: .cannotComplete, attempts: 3) }) })
    let pageQueries = pageFailed[name]?.recovery?["queries"] as? [[String: Any]]
    let pages = pageQueries?[1]["pages"] as? [[String: Any]]
    guard pageFailed[name]?.error == .cannotComplete, pageFailed[name]?.value == nil,
          (pages?.first?["status"] as? [String: Any])?["code"] as? Int32 == AXError.cannotComplete.rawValue else {
        throw EngineError.message("Composite native page failure evidence fixture failed.")
    }
    let unsupported = ReadResult<CFTypeRef>(value: nil, error: .attributeUnsupported, attempts: 1)
    let recoveredUnsupported = recoverNativeMetadataReads([name], initial: [name: unsupported], batchQuery: { ReadResult(value: nil, error: .failure, attempts: 1) },
                                                          arrayQuery: { _, result in recoverNativeArray(result, count: { ReadResult(value: NSNumber(value: 0), error: .success, attempts: 1) }, values: { _, _ in throwawayArrayPage() }) })
    guard recoveredUnsupported[name]?.error == .success,
          (recoveredUnsupported[name]?.recovery?["initial_status"] as? [String: Any])?["code"] as? Int32 == AXError.attributeUnsupported.rawValue else {
        throw EngineError.message("Advertised unsupported-attribute native array recovery fixture failed.")
    }
    return 5
}

func nativeActionNamesRecoverySelfTest() throws -> Int {
    let initial = ReadResult<CFArray>(value: nil, error: .failure, attempts: 1)
    var fixtures = 0
    for names in [[], ["AXPress"]] {
        var calls = 0
        let result = recoverNativeActionNames(initial, query: { calls += 1; return ReadResult(value: names as CFArray, error: .success, attempts: 1) })
        guard calls == 1, result.error == .success, result.value as? [String] == names,
              result.recovery?["resolved"] as? Bool == true, result.recovery?["names_valid"] as? Bool == true,
              result.recovery?["returned_count"] as? Int == names.count else {
            throw EngineError.message("Native action-name genuine string-array recovery fixture failed.")
        }
        fixtures += 1
    }
    for query: ReadResult<CFArray> in [ReadResult(value: nil, error: .failure, attempts: 1),
                                     ReadResult(value: nil, error: .success, attempts: 1),
                                     ReadResult(value: ["AXPress", NSNumber(value: 0)] as CFArray, error: .success, attempts: 1),
                                     ReadResult(value: ["AXPress"] as CFArray, error: .attributeUnsupported, attempts: 1)] {
        let result = recoverNativeActionNames(initial, query: { query })
        guard result.error == .failure, result.value == nil, result.recovery?["resolved"] as? Bool == false else {
            throw EngineError.message("Native action-name failed/malformed recovery fixture failed.")
        }
        fixtures += 1
    }
    for untouched: ReadResult<CFArray> in [ReadResult(value: nil, error: .cannotComplete, attempts: 3),
                                         ReadResult(value: [] as CFArray, error: .success, attempts: 1)] {
        var calls = 0
        let result = recoverNativeActionNames(untouched, query: { calls += 1; return ReadResult(value: nil, error: .failure, attempts: 1) })
        guard calls == 0, result.error == untouched.error, result.recovery == nil else {
            throw EngineError.message("Native action-name non-failure query exclusion fixture failed.")
        }
        fixtures += 1
    }
    let presentFailure = ReadResult<CFArray>(value: ["AXPress"] as CFArray, error: .failure, attempts: 1)
    let stillFailed = recoverNativeActionNames(presentFailure, query: { ReadResult(value: nil, error: .failure, attempts: 1) })
    guard stillFailed.error == .failure, stillFailed.value as? [String] == ["AXPress"],
          nativeActionNamesForExport(stillFailed) == nil,
          stillFailed.recovery?["initial_has_array"] as? Bool == true,
          stillFailed.recovery?["initial_returned_count"] as? Int == 1 else {
        throw EngineError.message("Failed native action-name arrays were advertised or their returned evidence was discarded.")
    }
    fixtures += 1
    return fixtures
}

func nativeArrayRecoverySelfTest() throws -> Int {
    let original = ReadResult<CFTypeRef>(value: nil, error: .failure, attempts: 1)
    var pageCalls = 0
    let empty = recoverNativeArray(original, count: { ReadResult(value: NSNumber(value: 0), error: .success, attempts: 1) },
                                   values: { _, _ in pageCalls += 1; return ReadResult(value: nil, error: .failure, attempts: 1) })
    guard empty.error == .success, (empty.value as? [Any])?.isEmpty == true, pageCalls == 0,
          (empty.recovery?["initial_status"] as? [String: Any])?["code"] as? Int32 == AXError.failure.rawValue else {
        throw EngineError.message("Native array empty-count recovery fixture failed.")
    }
    let failedCount = recoverNativeArray(original, count: { ReadResult(value: nil, error: .failure, attempts: 1) },
                                         values: { _, _ in throwawayArrayPage() })
    guard failedCount.error == .failure, failedCount.value == nil, failedCount.recovery?["resolved"] as? Bool == false else {
        throw EngineError.message("Failed native count was incorrectly recovered.")
    }
    let full = (0..<600).map { NSNumber(value: $0) }
    let paged = recoverNativeArray(original, count: { ReadResult(value: NSNumber(value: 600), error: .success, attempts: 1) },
                                  values: { start, count in ReadResult(value: Array(full[start..<(start + count)]) as CFArray, error: .success, attempts: 1) })
    guard paged.error == .success, (paged.value as? [NSNumber]) == full,
          (paged.recovery?["pages"] as? [[String: Any]])?.count == 3 else { throw EngineError.message("Native array paging fixture failed.") }
    let short = recoverNativeArray(original, count: { ReadResult(value: NSNumber(value: 2), error: .success, attempts: 1) },
                                  values: { _, _ in ReadResult(value: [NSNumber(value: 1)] as CFArray, error: .success, attempts: 1) })
    let shortPages = short.recovery?["pages"] as? [[String: Any]]
    guard short.error == .failure, short.value == nil,
          shortPages?.first?["has_value"] as? Bool == true,
          shortPages?.first?["returned_count"] as? Int == 1 else {
        throw EngineError.message("Short native page was incorrectly accepted or its length was not retained.")
    }
    var countCalls = 0
    let changing = recoverNativeArray(original, count: { countCalls += 1; return ReadResult(value: NSNumber(value: countCalls == 1 ? 0 : 1), error: .success, attempts: 1) },
                                     values: { _, _ in throwawayArrayPage() })
    guard changing.error == .failure, changing.value == nil else { throw EngineError.message("Changing native count was incorrectly accepted.") }
    let invalid = ReadResult<CFTypeRef>(value: nil, error: .invalidUIElement, attempts: 1)
    var unexpectedCalls = 0
    let invalidResult = recoverNativeArray(invalid, count: { unexpectedCalls += 1; return ReadResult(value: NSNumber(value: 0), error: .success, attempts: 1) },
                                          values: { _, _ in throwawayArrayPage() })
    guard invalidResult.error == .invalidUIElement, unexpectedCalls == 0 else { throw EngineError.message("Invalid native handle was treated as an empty array.") }
    let pageError = recoverNativeArray(original, count: { ReadResult(value: NSNumber(value: 1), error: .success, attempts: 1) },
                                      values: { _, _ in ReadResult(value: nil, error: .cannotComplete, attempts: 3) })
    let failedPages = pageError.recovery?["pages"] as? [[String: Any]]
    guard pageError.error == .failure, pageError.value == nil,
          failedPages?.first?["has_value"] as? Bool == false,
          failedPages?.first?["returned_count"] is NSNull else {
        throw EngineError.message("Failed native page was incorrectly accepted or its absent value was not retained.")
    }
    let present = ReadResult<CFTypeRef>(value: [] as CFArray, error: .success, attempts: 1)
    let untouched = recoverNativeArray(present, count: { unexpectedCalls += 1; return ReadResult(value: nil, error: .failure, attempts: 1) },
                                      values: { _, _ in throwawayArrayPage() })
    guard untouched.error == .success, untouched.recovery == nil, unexpectedCalls == 0 else { throw EngineError.message("Successful array read was unnecessarily recovered.") }
    return 8
}

private func throwawayArrayPage() -> ReadResult<CFArray> {
    ReadResult(value: nil, error: .failure, attempts: 1)
}

let counts = ["nativeMetadataBatchRecoverySelfTest": try nativeMetadataBatchRecoverySelfTest(),
              "nativeMetadataCompositeRecoverySelfTest": try nativeMetadataCompositeRecoverySelfTest(),
              "nativeActionNamesRecoverySelfTest": try nativeActionNamesRecoverySelfTest(),
              "nativeArrayRecoverySelfTest": try nativeArrayRecoverySelfTest(),
              "nativeAbsenceRecoverySelfTest": try nativeAbsenceRecoverySelfTest()]
var nodes: [[String: Any]] = []
var failures: [[String: Any]] = []
var recoveryAttempts = 0, recoverySuccesses = 0, valueSuccesses = 0, absenceSuccesses = 0
var absentValues: [[String: Any]] = []
func addMetadataNode(_ label: String, _ names: [String], _ results: [String: ReadResult<CFTypeRef>]) {
    let identifier = nodes.count
    var attributes: [String: Any] = [:], statuses: [String: Any] = [:], traces: [String: Any] = [:]
    for name in names {
        let result = results[name]!
        statuses[name] = result.status
        if result.error == .success, let value = result.value { attributes[name] = value }
        if let trace = result.recovery {
            traces[name] = trace; recoveryAttempts += 1
            if trace["resolved"] as? Bool == true {
                recoverySuccesses += 1
                if trace["resolution_kind"] as? String == "absence" { absenceSuccesses += 1 }
                else { valueSuccesses += 1 }
            }
        }
        if result.error == .noValue { absentValues.append(["node": identifier, "attribute": name, "status": result.status]) }
        if result.error != .success && result.error != .noValue {
            failures.append(["node": identifier, "attribute": name, "stage": "attribute_read", "status": result.status])
        }
    }
    nodes.append(["id": identifier, "fixture": label, "attribute_names": names, "attributes": attributes,
                  "attribute_statuses": statuses, "native_read_recoveries": traces, "action_names": [],
                  "action_names_status": ["code": 0, "name": "success", "attempts": 1]])
}
func addActionNode(_ label: String, _ result: ReadResult<CFArray>) {
    let identifier = nodes.count
    var traces: [String: Any] = [:]
    if let trace = result.recovery {
        traces["action_names"] = trace; recoveryAttempts += 1
        if trace["resolved"] as? Bool == true {
                recoverySuccesses += 1
                if trace["resolution_kind"] as? String == "absence" { absenceSuccesses += 1 }
                else { valueSuccesses += 1 }
            }
    }
    if result.error != .success {
        failures.append(["node": identifier, "attribute": "action_names", "stage": "enumeration", "status": result.status])
    }
    nodes.append(["id": identifier, "fixture": label, "attribute_names": [], "attributes": [:],
                  "attribute_statuses": [:], "native_read_recoveries": traces,
                  "action_names": (nativeActionNamesForExport(result) ?? []).sorted(), "action_names_status": result.status])
}
func failedAttributes(_ names: [String], _ error: AXError = .failure) -> [String: ReadResult<CFTypeRef>] {
    Dictionary(uniqueKeysWithValues: names.map { ($0, ReadResult(value: nil, error: error, attempts: error == .cannotComplete ? 3 : 1)) })
}
func noArray(_ original: ReadResult<CFTypeRef>) -> ReadResult<CFTypeRef> {
    recoverNativeArray(original, count: { ReadResult(value: nil, error: .illegalArgument, attempts: 1) }, values: { _, _ in throwawayArrayPage() })
}
let valuesNames = ["AXEnabled", "AXValue", "AXSelectedTextRanges"]
let values = recoverNativeMetadataReads(valuesNames, initial: failedAttributes(valuesNames), batchQuery: {
    ReadResult(value: [kCFBooleanFalse!, NSNumber(value: 0), [] as CFArray] as CFArray, error: .success, attempts: 1)
}, arrayQuery: { _, original in noArray(original) })
addMetadataNode("bulk_native_false_zero_empty_array", valuesNames, values)
let rangeName = "AXSelectedTextRanges"
let range = recoverNativeMetadataReads([rangeName], initial: failedAttributes([rangeName], .cannotComplete), batchQuery: {
    ReadResult(value: [kCFNull!] as CFArray, error: .success, attempts: 1)
}, arrayQuery: { _, original in
    recoverNativeArray(original, count: { ReadResult(value: NSNumber(value: 0), error: .success, attempts: 1) }, values: { _, _ in throwawayArrayPage() })
})
addMetadataNode("bulk_null_then_native_empty_array", [rangeName], range)
let titleName = "AXTitle"
let nullScalar = recoverNativeMetadataReads([titleName], initial: failedAttributes([titleName], .cannotComplete), batchQuery: {
    ReadResult(value: [kCFNull!] as CFArray, error: .success, attempts: 1)
}, arrayQuery: { _, original in noArray(original) })
addMetadataNode("bulk_null_then_scalar_array_query_rejected", [titleName], nullScalar)
var slotError = AXError.attributeUnsupported
let errorValue = AXValueCreate(.axError, &slotError)!
let envelope = recoverNativeMetadataReads([titleName], initial: failedAttributes([titleName]), batchQuery: {
    ReadResult(value: [errorValue] as CFArray, error: .success, attempts: 1)
}, arrayQuery: { _, original in noArray(original) })
addMetadataNode("bulk_native_error_envelope_then_scalar_rejected", [titleName], envelope)
for (label, payload, error): (String, CFArray?, AXError) in [
    ("bulk_outer_failure_with_present_array", ["Native title"] as CFArray, .cannotComplete),
    ("bulk_success_nil", nil, .success),
    ("bulk_short_cardinality", [] as CFArray, .success),
    ("bulk_long_cardinality", ["one", "two"] as CFArray, .success)] {
    let result = recoverNativeMetadataReads([titleName], initial: failedAttributes([titleName]), batchQuery: {
        ReadResult(value: payload, error: error, attempts: 1)
    }, arrayQuery: { _, original in noArray(original) })
    addMetadataNode(label, [titleName], result)
}
let actionsInitial = ReadResult<CFArray>(value: nil, error: .failure, attempts: 1)
addActionNode("action_native_success_empty", recoverNativeActionNames(actionsInitial, query: { ReadResult(value: [] as CFArray, error: .success, attempts: 1) }))
addActionNode("action_native_success_press", recoverNativeActionNames(actionsInitial, query: { ReadResult(value: ["AXPress"] as CFArray, error: .success, attempts: 1) }))
addActionNode("action_malformed_native_array", recoverNativeActionNames(actionsInitial, query: { ReadResult(value: ["AXPress", NSNumber(value: 0)] as CFArray, error: .success, attempts: 1) }))
addActionNode("action_failed_query_with_present_array", recoverNativeActionNames(actionsInitial, query: { ReadResult(value: ["AXPress"] as CFArray, error: .attributeUnsupported, attempts: 1) }))
let presentInitial = ReadResult<CFArray>(value: ["AXPress"] as CFArray, error: .failure, attempts: 1)
addActionNode("action_original_failure_present_array_still_hidden", recoverNativeActionNames(presentInitial, query: { ReadResult(value: nil, error: .failure, attempts: 1) }))

var absenceError = AXError.noValue
let absenceEnvelope = AXValueCreate(.axError, &absenceError)!
let absenceName = "AXHelp"
let cannotCompleteInitial = failedAttributes([absenceName], .cannotComplete)
let absent = recoverNativeMetadataReads([absenceName], initial: cannotCompleteInitial, batchQuery: {
    ReadResult(value: [absenceEnvelope] as CFArray, error: .success, attempts: 1)
}, arrayQuery: { _, _ in fatalError("Confirmed absence must not perform array recovery.") })
addMetadataNode("exact_bulk_noValue_from_cannotComplete", [absenceName], absent)
let untrustedOriginal = ReadResult<CFTypeRef>(value: kCFBooleanTrue!, error: .failure, attempts: 1)
let noUntrustedValue = recoverNativeMetadataReads([absenceName], initial: [absenceName: untrustedOriginal], batchQuery: {
    ReadResult(value: [absenceEnvelope] as CFArray, error: .success, attempts: 1)
}, arrayQuery: { _, _ in fatalError("Confirmed absence must not perform array recovery.") })
addMetadataNode("exact_bulk_noValue_discards_original_failed_value", [absenceName], noUntrustedValue)
let mixedNames = [absenceName, rangeName]
let mixedOutcomes = recoverNativeMetadataReads(mixedNames, initial: failedAttributes(mixedNames), batchQuery: {
    ReadResult(value: [absenceEnvelope, [] as CFArray] as CFArray, error: .success, attempts: 1)
}, arrayQuery: { _, _ in fatalError("Exact absence/value slots must not perform array recovery.") })
addMetadataNode("exact_bulk_mixed_noValue_and_real_empty_array", mixedNames, mixedOutcomes)
for (label, payload, error): (String, CFArray?, AXError) in [
    ("noValue_envelope_with_wrong_cardinality_unresolved", [absenceEnvelope, absenceEnvelope] as CFArray, .success),
    ("noValue_envelope_with_failed_outer_query_unresolved", [absenceEnvelope] as CFArray, .failure)] {
    let result = recoverNativeMetadataReads([absenceName], initial: failedAttributes([absenceName]), batchQuery: {
        ReadResult(value: payload, error: error, attempts: 1)
    }, arrayQuery: { _, original in noArray(original) })
    addMetadataNode(label, [absenceName], result)
}
var successError = AXError.success
let successEnvelope = AXValueCreate(.axError, &successError)!
let falseSuccess = recoverNativeMetadataReads([absenceName], initial: failedAttributes([absenceName]), batchQuery: {
    ReadResult(value: [successEnvelope] as CFArray, error: .success, attempts: 1)
}, arrayQuery: { _, original in noArray(original) })
addMetadataNode("success_error_envelope_is_unresolved", [absenceName], falseSuccess)

let artifact: [String: Any] = ["fixture_kind": "offline_native_query_recovery",
 "fixture_scope": "Synthetic callbacks execute the actual Swift recovery helpers. No application, AXUIElement, native query, action, or capture is used.",
 "helper_fixture_counts": counts, "nodes": nodes, "node_count": nodes.count,
 "metadata_classification_version": 2, "metadata_failures": failures, "metadata_read_failures": failures, "serialization_warnings": [],
 "native_read_recovery_attempts": recoveryAttempts, "native_read_recovery_successes": recoverySuccesses,
 "native_read_recovery_outcome_version": 2, "native_read_recovery_value_successes": valueSuccesses,
 "native_read_recovery_absence_successes": absenceSuccesses, "absent_attribute_values": absentValues,
 "scope": ["hierarchy_attributes": ["AXChildren", "AXWindows", "AXRows", "AXColumns", "AXSplitters"]]]
let output = URL(fileURLWithPath: "/Users/ahmedelamin/Documents/Codex/2026-10-09/i-ha/native-ax-engine/artifacts/native-absence-recovery-20261010/native-query-fixtures.json")
try FileManager.default.createDirectory(at: output.deletingLastPathComponent(), withIntermediateDirectories: true)
try JSONSerialization.data(withJSONObject: artifact, options: [.prettyPrinted, .sortedKeys]).write(to: output, options: .atomic)
let summary: [String: Any] = ["self_tests": counts, "new_fixture_total": counts.values.reduce(0, +) - counts["nativeArrayRecoverySelfTest"]!, "artifact_nodes": nodes.count,
 "native_read_recovery_attempts": recoveryAttempts, "native_read_recovery_successes": recoverySuccesses,
 "native_read_recovery_outcome_version": 2, "native_read_recovery_value_successes": valueSuccesses,
 "native_read_recovery_absence_successes": absenceSuccesses, "artifact": output.path]
print(String(data: try JSONSerialization.data(withJSONObject: summary, options: [.sortedKeys]), encoding: .utf8)!)
